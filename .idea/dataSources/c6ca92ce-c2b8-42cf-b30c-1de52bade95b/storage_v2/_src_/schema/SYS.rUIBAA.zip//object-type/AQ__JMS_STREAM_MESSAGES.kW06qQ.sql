CREATE type aq$_jms_stream_messages
                                                                      
as varray(2147483647) of aq$_jms_stream_message;
/

