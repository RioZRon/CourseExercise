CREATE type ku$_outline_hint_list_t
 as table of ku$_outline_hint_t
/

