CREATE VIEW USER_SYS_PRIVS AS
  select decode(sa.grantee#,1,'PUBLIC',su.name),spm.name,
       decode(min(mod(option$, 2)),1,'YES','NO'), 'NO', 'NO'
from  sys.system_privilege_map spm, sys.sysauth$ sa, sys.user$ su
where ((sa.grantee#=userenv('SCHEMAID') and su.user#=sa.grantee#)
       or sa.grantee#=1)
  and sa.privilege#=spm.privilege
  and bitand(nvl(option$, 0), 4) = 0
group by decode(sa.grantee#,1,'PUBLIC',su.name),spm.name
union all
/* Commonly granted Privileges */
select decode(sa.grantee#,1,'PUBLIC',su.name),spm.name,
       decode(min(bitand(option$,16)),16,'YES','NO'),
       'YES', decode(SYS_CONTEXT('USERENV', 'CON_ID'), 1, 'NO', 'YES')
from  sys.system_privilege_map spm, sys.sysauth$ sa, sys.user$ su
where ((sa.grantee#=userenv('SCHEMAID') and su.user#=sa.grantee#)
       or sa.grantee#=1)
  and sa.privilege#=spm.privilege
  and bitand(option$,8) = 8
group by decode(sa.grantee#,1,'PUBLIC',su.name),spm.name
union all
/* Federationally granted Privileges */
select decode(sa.grantee#,1,'PUBLIC',su.name),spm.name,
       decode(min(bitand(option$,128)),128,'YES','NO'),
       'YES',
       decode(SYS_CONTEXT('USERENV', 'IS_APPLICATION_PDB'), 'YES', 'YES', 'NO')
from  sys.system_privilege_map spm, sys.sysauth$ sa, sys.user$ su
where ((sa.grantee#=userenv('SCHEMAID') and su.user#=sa.grantee#)
       or sa.grantee#=1)
  and sa.privilege#=spm.privilege
  and bitand(option$,64) = 64
group by decode(sa.grantee#,1,'PUBLIC',su.name),spm.name
/

