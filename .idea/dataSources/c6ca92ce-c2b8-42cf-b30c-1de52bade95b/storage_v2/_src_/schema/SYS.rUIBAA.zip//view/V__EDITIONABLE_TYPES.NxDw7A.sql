CREATE VIEW V_$EDITIONABLE_TYPES AS
  select "EDITIONABLE_TYPE","TYPE#","CON_ID" from v$editionable_types
/

