CREATE TYPE LCR$_PROCEDURE_RECORD
                                      
AS OPAQUE VARYING (*)
USING LIBRARY lcr_prc_lib
(
   MAP MEMBER FUNCTION map_lcr RETURN NUMBER,
  MEMBER FUNCTION  get_source_database_name RETURN VARCHAR2,
   MEMBER FUNCTION  get_scn                  RETURN NUMBER,
  MEMBER FUNCTION  get_transaction_id       RETURN VARCHAR2,
   MEMBER FUNCTION  get_publication          RETURN VARCHAR2,
   MEMBER FUNCTION  get_package_owner        RETURN VARCHAR2,
   MEMBER FUNCTION  get_package_name         RETURN VARCHAR2,
   MEMBER FUNCTION  get_procedure_name       RETURN VARCHAR2,
   MEMBER FUNCTION  get_parameters           RETURN SYS.LCR$_PARAMETER_LIST,
   MEMBER FUNCTION  get_compatible           RETURN NUMBER,
   MEMBER FUNCTION get_source_time RETURN DATE,
   MEMBER FUNCTION get_thread_number RETURN NUMBER,
   MEMBER FUNCTION get_position RETURN RAW,
   MEMBER FUNCTION  get_tag                  RETURN RAW,
   MEMBER FUNCTION is_null_tag  RETURN VARCHAR2,
   MEMBER FUNCTION  get_root_name            RETURN VARCHAR2,
   MEMBER FUNCTION  get_logon_user           RETURN VARCHAR2,
   MEMBER FUNCTION  get_current_user         RETURN VARCHAR2,
   MEMBER FUNCTION  get_default_user         RETURN VARCHAR2
)
/

