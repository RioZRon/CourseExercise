CREATE TYPE     sh$shard_meta_list AS VARRAY(1000000) OF sys.sh$shard_meta;
/

