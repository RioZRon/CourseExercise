CREATE type ku$_objgrant_list_t
  as table of ku$_objgrant_t
/

