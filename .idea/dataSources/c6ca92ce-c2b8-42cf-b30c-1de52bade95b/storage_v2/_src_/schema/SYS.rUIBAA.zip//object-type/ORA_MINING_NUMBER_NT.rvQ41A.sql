CREATE type ora_mining_number_nt
                                       as table of number
/

