CREATE TYPE  HSBLKValAry as  VARRAY(250)  of varchar2(4000);
/

