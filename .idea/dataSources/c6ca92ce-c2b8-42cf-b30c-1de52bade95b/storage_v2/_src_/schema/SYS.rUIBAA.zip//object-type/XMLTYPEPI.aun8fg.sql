CREATE type XMLTypePI                                        as
varray(2147483647) of RAW(2000);
/

