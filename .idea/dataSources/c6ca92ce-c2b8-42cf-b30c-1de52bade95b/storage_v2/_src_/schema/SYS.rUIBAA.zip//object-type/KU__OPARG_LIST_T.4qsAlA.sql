CREATE type ku$_oparg_list_t as TABLE of ku$_oparg_t
/

