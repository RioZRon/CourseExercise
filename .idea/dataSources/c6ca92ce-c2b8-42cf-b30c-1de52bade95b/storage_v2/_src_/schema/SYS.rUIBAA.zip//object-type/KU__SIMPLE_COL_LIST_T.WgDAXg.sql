CREATE type ku$_simple_col_list_t
 as table of ku$_simple_col_t
/

