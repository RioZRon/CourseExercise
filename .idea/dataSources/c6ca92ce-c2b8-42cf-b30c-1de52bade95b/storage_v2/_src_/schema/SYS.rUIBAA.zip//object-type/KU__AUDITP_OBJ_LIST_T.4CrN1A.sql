CREATE type ku$_auditp_obj_list_t
  as table of ku$_auditp_obj_t
/

