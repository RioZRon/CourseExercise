CREATE TYPE     re$attribute_value_list
AS VARRAY(1024) OF sys.re$attribute_value
/

