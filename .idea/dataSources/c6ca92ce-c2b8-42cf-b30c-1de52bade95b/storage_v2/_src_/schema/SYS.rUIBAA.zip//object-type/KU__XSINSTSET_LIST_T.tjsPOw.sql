CREATE type ku$_xsinstset_list_t as table of ku$_xsinstset_t;
/

