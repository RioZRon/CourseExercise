CREATE TYPE ku$_ObjNumPairList  IS TABLE OF ku$_ObjNumPair
/

