CREATE type ku$_opancillary_list_t as TABLE of ku$_opancillary_t
/

