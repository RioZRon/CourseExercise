CREATE TYPE     re$nv_array
                                                                      
AS VARRAY(1024) of sys.re$nv_node
/

