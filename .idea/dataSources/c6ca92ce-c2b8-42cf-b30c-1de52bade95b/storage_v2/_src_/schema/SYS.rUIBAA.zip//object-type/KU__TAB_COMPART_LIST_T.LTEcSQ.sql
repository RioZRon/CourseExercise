CREATE type ku$_tab_compart_list_t as table of ku$_tab_compart_t
/

