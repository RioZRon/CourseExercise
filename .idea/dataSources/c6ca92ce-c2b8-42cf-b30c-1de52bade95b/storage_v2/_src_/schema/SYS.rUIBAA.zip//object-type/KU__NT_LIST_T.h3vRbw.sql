CREATE type ku$_nt_list_t as table of ku$_nt_t
/

