CREATE TYPE sqlset AS TABLE OF sqlset_row
/

