CREATE type ku$_ind_part_list_t as table of ku$_ind_part_t
/

