CREATE TYPE     re$name_array AS VARRAY(1024) of varchar2(30)
 alter type     re$name_array modify element type varchar2(128)
           CASCADE
/

