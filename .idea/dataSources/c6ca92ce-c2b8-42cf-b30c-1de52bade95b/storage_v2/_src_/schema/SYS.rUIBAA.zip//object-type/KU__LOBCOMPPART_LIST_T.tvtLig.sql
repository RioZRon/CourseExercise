CREATE type ku$_lobcomppart_list_t as table of ku$_lobcomppart_t
/

