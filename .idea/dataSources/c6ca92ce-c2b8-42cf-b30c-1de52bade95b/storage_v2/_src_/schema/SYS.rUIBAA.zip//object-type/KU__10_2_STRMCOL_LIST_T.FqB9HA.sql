CREATE type ku$_10_2_strmcol_list_t as table of ku$_10_2_strmcol_t
/

