CREATE type ku$_attr_dim_lvl_key_list_t
  as table of ku$_attr_dim_lvl_key_t
/

