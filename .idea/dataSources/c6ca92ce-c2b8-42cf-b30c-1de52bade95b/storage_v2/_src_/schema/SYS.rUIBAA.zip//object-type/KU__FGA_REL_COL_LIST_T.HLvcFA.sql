CREATE type ku$_fga_rel_col_list_t
  as table of ku$_fga_rel_col_t;
/

