CREATE type ku$_indarraytype_list_t as table of ku$_indarraytype_t
/

