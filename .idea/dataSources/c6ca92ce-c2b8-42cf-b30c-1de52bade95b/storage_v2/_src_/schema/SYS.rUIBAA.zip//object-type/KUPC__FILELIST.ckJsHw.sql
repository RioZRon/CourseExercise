CREATE TYPE kupc$_fileList AS TABLE OF kupc$_fileInfo
/

