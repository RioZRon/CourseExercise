CREATE type ku$_strmsubcoltype_list_t
 as table of ku$_strmsubcoltype_t
/

