CREATE type ku$_profile_list_t as TABLE of ku$_profile_attr_t
/

