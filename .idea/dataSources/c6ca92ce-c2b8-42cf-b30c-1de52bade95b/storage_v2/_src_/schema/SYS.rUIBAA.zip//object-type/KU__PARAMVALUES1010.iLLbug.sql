CREATE TYPE     ku$_ParamValues1010 AS TABLE OF sys.ku$_ParamValue1010
/

