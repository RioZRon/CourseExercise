CREATE type ku$_hcs_av_cache_lvl_list_t
  as table of ku$_hcs_av_cache_lvl_t
/

