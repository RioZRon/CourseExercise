CREATE type     grant_path AS VARRAY(150) OF VARCHAR2(128);
/

