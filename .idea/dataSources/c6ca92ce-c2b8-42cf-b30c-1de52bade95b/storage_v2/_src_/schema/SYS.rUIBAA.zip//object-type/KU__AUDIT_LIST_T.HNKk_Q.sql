CREATE TYPE     ku$_audit_list_t IS TABLE OF sys.ku$_audobj_t
/

