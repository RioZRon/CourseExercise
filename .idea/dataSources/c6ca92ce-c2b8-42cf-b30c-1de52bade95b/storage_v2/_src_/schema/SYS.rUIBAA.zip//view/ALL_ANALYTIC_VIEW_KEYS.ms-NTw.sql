CREATE VIEW ALL_ANALYTIC_VIEW_KEYS AS
  select OWNER,
       ANALYTIC_VIEW_NAME,
       DIMENSION_ALIAS,
       AV_KEY_TABLE_ALIAS,
       AV_KEY_COLUMN,
       REF_DIMENSION_ATTR,
       ORDER_NUM,
       ORIGIN_CON_ID
from  INT$DBA_AVIEW_KEYS
where OWNER = SYS_CONTEXT('USERENV', 'CURRENT_USER')
       or OWNER='PUBLIC'
       or OBJ_ID(OWNER, ANALYTIC_VIEW_NAME, OBJECT_TYPE, OBJECT_ID) in
            ( select obj#  -- directly granted privileges
              from sys.objauth$
              where grantee# in ( select kzsrorol from x$kzsro )
            )
       or ora_check_sys_privilege(owner_id, object_type) = 1
/

