CREATE type ku$_subcoltype_list_t as table of ku$_subcoltype_t
/

