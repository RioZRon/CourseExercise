CREATE VIEW DATABASE_COMPATIBLE_LEVEL AS
  select value,description
from v$parameter
where name = 'compatible'
/

