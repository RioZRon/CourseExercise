CREATE VIEW NLS_INSTANCE_PARAMETERS AS
  select substr(upper(v.name), 1, 30),
       substr(v.value, 1, 64)
from v$system_parameter v,
     (select sys_context('userenv', 'con_id') con_id from dual) b
where v.name like 'nls%' and
      (v.con_id = 0 or  v.con_id = b.con_id)
/

