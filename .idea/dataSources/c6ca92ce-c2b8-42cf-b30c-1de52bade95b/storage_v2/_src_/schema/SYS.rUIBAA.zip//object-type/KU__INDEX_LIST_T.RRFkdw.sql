CREATE type ku$_index_list_t as table of ku$_index_t;
/

