CREATE type aq$_jms_object_messages
                                                                      
as varray(2147483647) of aq$_jms_object_message;
/

