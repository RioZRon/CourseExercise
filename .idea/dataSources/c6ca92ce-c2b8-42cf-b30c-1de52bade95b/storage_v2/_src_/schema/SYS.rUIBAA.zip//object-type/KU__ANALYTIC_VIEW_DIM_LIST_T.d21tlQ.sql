CREATE type ku$_analytic_view_dim_list_t
  as table of ku$_analytic_view_dim_t
/

