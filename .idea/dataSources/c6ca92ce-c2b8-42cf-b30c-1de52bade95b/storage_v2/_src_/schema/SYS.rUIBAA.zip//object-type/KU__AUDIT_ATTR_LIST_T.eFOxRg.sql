CREATE type ku$_audit_attr_list_t
  as table of varchar2(128)
/

