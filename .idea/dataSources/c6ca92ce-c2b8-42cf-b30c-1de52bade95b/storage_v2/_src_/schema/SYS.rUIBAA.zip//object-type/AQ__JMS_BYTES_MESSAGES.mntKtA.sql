CREATE type aq$_jms_bytes_messages
                                                                      
as varray(2147483647) of aq$_jms_bytes_message;
/

