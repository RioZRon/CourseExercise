CREATE type ku$_col_stats_list_t
  as table of ku$_col_stats_t
/

