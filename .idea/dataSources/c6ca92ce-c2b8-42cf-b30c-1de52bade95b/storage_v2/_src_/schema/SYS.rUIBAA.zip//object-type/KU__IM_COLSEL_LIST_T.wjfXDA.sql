CREATE type ku$_im_colsel_list_t as table of ku$_im_colsel_t
/

