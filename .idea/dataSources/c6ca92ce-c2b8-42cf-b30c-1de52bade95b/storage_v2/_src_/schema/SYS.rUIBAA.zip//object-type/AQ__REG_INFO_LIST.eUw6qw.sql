CREATE TYPE     aq$_reg_info_list
AS VARRAY(1024) OF sys.aq$_reg_info
/

