CREATE TYPE GenInterfaceStubSequence AS VARRAY(32767) OF GenInterfaceStub;
/

