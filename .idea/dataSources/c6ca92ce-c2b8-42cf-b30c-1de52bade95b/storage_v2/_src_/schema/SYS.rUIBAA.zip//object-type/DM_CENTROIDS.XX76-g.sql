CREATE type dm_centroids
                                       as table of dm_centroid
/

