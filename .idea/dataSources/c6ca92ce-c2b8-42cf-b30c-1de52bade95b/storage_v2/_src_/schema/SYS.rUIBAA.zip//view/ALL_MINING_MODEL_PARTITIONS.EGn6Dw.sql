CREATE VIEW ALL_MINING_MODEL_PARTITIONS AS
  select owner, model_name, partition_name, position, column_name, hiboundval from (
select u.name owner,
       o.name model_name,
       o.subname partition_name,
       mp.pos#  position,
       mpc.name column_name,
       hiboundval
from modelpart$ mp, obj$ o, modelpartcol$ mpc, sys.user$ u
where mp.obj#=o.obj#
  and o.owner#=u.user#
  and (o.owner#=userenv('SCHEMAID')
    or mp.mod# in
            (select oa.obj#
             from sys.objauth$ oa
             where oa.grantee# in ( select kzsrorol
                                         from x$kzsro
                                  )
            )
        or /* user has system privileges */
          ora_check_sys_privilege (o.owner#, o.type#) = 1
      )
  and mp.mod#=mpc.obj#
  and mp.pos#=mpc.pos#
  and mp.pos# is not null)
/

