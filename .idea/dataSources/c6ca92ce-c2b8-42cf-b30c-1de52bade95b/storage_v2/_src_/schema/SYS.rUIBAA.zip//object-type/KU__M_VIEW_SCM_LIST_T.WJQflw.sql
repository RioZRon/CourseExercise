CREATE type ku$_m_view_scm_list_t
  as table of ku$_m_view_scm_t
/

