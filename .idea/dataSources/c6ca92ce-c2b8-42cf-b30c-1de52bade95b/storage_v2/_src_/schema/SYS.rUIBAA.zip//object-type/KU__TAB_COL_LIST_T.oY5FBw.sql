CREATE type ku$_tab_col_list_t
  as table of ku$_tab_col_t
/

