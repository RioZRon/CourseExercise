CREATE VIEW GV_$TIMEZONE_NAMES AS
  select "TZNAME","TZABBREV","CON_ID" from gv$timezone_names
/

