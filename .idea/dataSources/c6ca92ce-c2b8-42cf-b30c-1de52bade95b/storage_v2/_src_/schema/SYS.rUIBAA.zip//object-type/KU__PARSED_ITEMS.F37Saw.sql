CREATE TYPE     ku$_parsed_items IS TABLE OF sys.ku$_parsed_item;
/

