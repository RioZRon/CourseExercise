CREATE type ku$_m_view_srt_list_t
  as table of ku$_m_view_srt_t
/

