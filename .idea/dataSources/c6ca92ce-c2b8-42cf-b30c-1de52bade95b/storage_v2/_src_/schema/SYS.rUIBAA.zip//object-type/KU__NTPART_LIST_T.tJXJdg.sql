CREATE type ku$_ntpart_list_t as table of ku$_ntpart_t
/

