CREATE TYPE aq$_midarray as varray(1024) of VARCHAR2(32);
/

