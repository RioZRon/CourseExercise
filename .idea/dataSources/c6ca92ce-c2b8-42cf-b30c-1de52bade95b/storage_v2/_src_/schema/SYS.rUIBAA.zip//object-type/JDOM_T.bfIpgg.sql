CREATE TYPE JDOM_T  FORCE
                                        AUTHID DEFINER AS
 OPAQUE VARYING (*) USING library DBMS_JDOM_LIB
(
  /* parse from string */
  STATIC FUNCTION  parse(jsn IN varchar2) return JDOM_T,
  STATIC FUNCTION  parse(jsn IN CLOB) return JDOM_T,
  STATIC FUNCTION  parse(jsn IN BLOB) return JDOM_T,

  /* create empty object/array*/
  STATIC FUNCTION  create_Obj return JDOM_T,
  STATIC FUNCTION  create_Arr return JDOM_T,

  /* serialize, convert */
  MEMBER FUNCTION  stringify      return VARCHAR2,
  MEMBER FUNCTION  to_String      return VARCHAR2,
  MEMBER FUNCTION  to_Clob(c CLOB) return CLOB,
  MEMBER FUNCTION  to_Blob(b BLOB) return BLOB,

  MEMBER FUNCTION  to_Boolean   return BOOLEAN,
  MEMBER FUNCTION  to_Number    return NUMBER,
  MEMBER FUNCTION  to_Date      return DATE,
  MEMBER FUNCTION  to_Timestamp return TIMESTAMP,

  /* introspection */
  MEMBER FUNCTION  is_Object    return BOOLEAN,
  MEMBER FUNCTION  is_Array     return BOOLEAN,

  MEMBER FUNCTION  is_Scalar    return BOOLEAN,
  MEMBER FUNCTION  is_String    return BOOLEAN,
  MEMBER FUNCTION  is_Number    return BOOLEAN,
  MEMBER FUNCTION  is_Boolean   return BOOLEAN,
  MEMBER FUNCTION  is_True      return BOOLEAN,
  MEMBER FUNCTION  is_False     return BOOLEAN,
  MEMBER FUNCTION  is_Null      return BOOLEAN,
  MEMBER FUNCTION  is_Date      return BOOLEAN,
  MEMBER FUNCTION  is_Timestamp return BOOLEAN,
  -- todo oranum, etc

  MEMBER FUNCTION  get_Size RETURN NUMBER,

  MEMBER FUNCTION  clone RETURN JDOM_T,

  /* error handling, can be combined like flags (3 = 1+2) */
  /* 0: raise no error  */
  /* 1: raise error on missing key */
  /* 2: raise on type mismatch  */
  MEMBER FUNCTION  on_Error(val NUMBER) RETURN BOOLEAN,

  /* object functions */
  MEMBER FUNCTION  put(key VARCHAR2, val VARCHAR2) RETURN BOOLEAN,

  MEMBER FUNCTION  put(key VARCHAR2, val NUMBER) RETURN BOOLEAN,
  MEMBER FUNCTION  put(key VARCHAR2, val BOOLEAN) RETURN BOOLEAN,
  MEMBER FUNCTION  put(key VARCHAR2, val DATE) RETURN BOOLEAN,
  MEMBER FUNCTION  put(key VARCHAR2, val TIMESTAMP) RETURN BOOLEAN,
  --MEMBER FUNCTION  put(key VARCHAR2, val CLOB) RETURN BOOLEAN,
  --MEMBER FUNCTION  put(key VARCHAR2, val BLOB) RETURN BOOLEAN,
  MEMBER FUNCTION  put(key VARCHAR2, val JDOM_T) RETURN BOOLEAN,
  MEMBER FUNCTION  put_Null(key VARCHAR2) RETURN BOOLEAN,

  MEMBER FUNCTION  get(key VARCHAR2) RETURN JDOM_T,
  MEMBER FUNCTION  get_String(key VARCHAR2) RETURN VARCHAR2,
  MEMBER FUNCTION  get_Number(key VARCHAR2) RETURN NUMBER,
  MEMBER FUNCTION  get_Boolean(key VARCHAR2) RETURN BOOLEAN,
  MEMBER FUNCTION  get_Date(key VARCHAR2) RETURN DATE,
  MEMBER FUNCTION  get_Timestamp(key VARCHAR2) RETURN TIMESTAMP,
  MEMBER FUNCTION  get_Clob(key VARCHAR2, c CLOB) RETURN CLOB,
  MEMBER FUNCTION  get_Blob(key VARCHAR2, b BLOB) RETURN BLOB,

  MEMBER FUNCTION  has_Key(key VARCHAR2) RETURN BOOLEAN,
  MEMBER FUNCTION  get_Keys RETURN JSON_KEY_LIST,
  MEMBER FUNCTION  get_Type(key VARCHAR2) RETURN VARCHAR2,
  MEMBER FUNCTION  remove(key VARCHAR2) RETURN BOOLEAN,
  MEMBER FUNCTION  rename_Key(keyOld VARCHAR2, keyNew VARCHAR2) RETURN BOOLEAN,

  /* array functions*/
  MEMBER FUNCTION  append(val VARCHAR2) RETURN BOOLEAN,
  MEMBER FUNCTION  append(val NUMBER) RETURN BOOLEAN,
  MEMBER FUNCTION  append(val BOOLEAN) RETURN BOOLEAN,
  MEMBER FUNCTION  append(val DATE) RETURN BOOLEAN,
  MEMBER FUNCTION  append(val TIMESTAMP) RETURN BOOLEAN,
  --MEMBER FUNCTION  append(val CLOB) RETURN BOOLEAN,
  --MEMBER FUNCTION  append(val BLOB) RETURN BOOLEAN,
  MEMBER FUNCTION  append(val JDOM_T) RETURN BOOLEAN,
  MEMBER FUNCTION  append_Null RETURN BOOLEAN,

  MEMBER FUNCTION  put(pos NUMBER, val VARCHAR2, overwrite BOOLEAN)
                   RETURN BOOLEAN,
  MEMBER FUNCTION  put(pos NUMBER, val NUMBER, overwrite BOOLEAN)
                   RETURN BOOLEAN,
  MEMBER FUNCTION  put(pos NUMBER, val BOOLEAN, overwrite BOOLEAN)
                   RETURN BOOLEAN,
  MEMBER FUNCTION  put(pos NUMBER, val DATE, overwrite BOOLEAN)
                   RETURN BOOLEAN,
  MEMBER FUNCTION  put(pos NUMBER, val TIMESTAMP, overwrite BOOLEAN)
                   RETURN BOOLEAN,
  --MEMBER FUNCTION  put(pos NUMBER, val CLOB, overwrite BOOLEAN)
  --                 RETURN BOOLEAN,
  --MEMBER FUNCTION  put(pos NUMBER, val BLOB, overwrite BOOLEAN)
  --                 RETURN BOOLEAN,
  MEMBER FUNCTION  put(pos NUMBER, val JDOM_T, overwrite BOOLEAN)
                   RETURN BOOLEAN,
  MEMBER FUNCTION  put_Null(pos NUMBER, overwrite BOOLEAN) RETURN BOOLEAN,

  MEMBER FUNCTION  get(pos NUMBER) RETURN JDOM_T,
  MEMBER FUNCTION  get_String(pos NUMBER) RETURN VARCHAR2,
  MEMBER FUNCTION  get_Number(pos NUMBER) RETURN NUMBER,
  MEMBER FUNCTION  get_Boolean(pos NUMBER) RETURN BOOLEAN,
  MEMBER FUNCTION  get_Date(pos NUMBER) RETURN DATE,
  MEMBER FUNCTION  get_Timestamp(pos NUMBER) RETURN TIMESTAMP,
  MEMBER FUNCTION  get_Clob(pos NUMBER, c CLOB) RETURN CLOB,
  MEMBER FUNCTION  get_Blob(pos NUMBER, b BLOB) RETURN BLOB,

  MEMBER FUNCTION  get_Type(pos NUMBER) RETURN VARCHAR2,
  MEMBER FUNCTION  remove(pos NUMBER) RETURN BOOLEAN,

  /* modification ('select' is called 'redact') */
  MEMBER FUNCTION  patch(spec VARCHAR2) RETURN BOOLEAN,
  MEMBER FUNCTION  redact(spec VARCHAR2) RETURN BOOLEAN,
  MEMBER FUNCTION  patch(spec JDOM_T) RETURN BOOLEAN,
  MEMBER FUNCTION  redact(spec JDOM_T) RETURN BOOLEAN
)
/

