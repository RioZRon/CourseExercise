CREATE TYPE     sh$deq_pmap_list AS VARRAY(1000000) OF sys.sh$deq_pmap;
/

