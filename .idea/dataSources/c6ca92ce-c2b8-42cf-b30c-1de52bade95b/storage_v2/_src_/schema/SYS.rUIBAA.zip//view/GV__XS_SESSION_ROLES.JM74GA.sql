CREATE VIEW GV_$XS_SESSION_ROLES AS
  select "INST_ID","ROLE_WSPACE","ROLE_NAME","FLAGS","CON_ID" from gv$xs_session_role
/

