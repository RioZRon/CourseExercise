CREATE type     package_array as varray(1024) of number;
/

