CREATE type ku$_sgi_col_list_t
  as table of ku$_sgi_col_t
/

