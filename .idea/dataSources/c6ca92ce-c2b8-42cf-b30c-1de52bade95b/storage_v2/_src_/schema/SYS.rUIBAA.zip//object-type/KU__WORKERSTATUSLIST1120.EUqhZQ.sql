CREATE TYPE     ku$_WorkerStatusList1120 AS TABLE OF sys.ku$_WorkerStatus1120
/

