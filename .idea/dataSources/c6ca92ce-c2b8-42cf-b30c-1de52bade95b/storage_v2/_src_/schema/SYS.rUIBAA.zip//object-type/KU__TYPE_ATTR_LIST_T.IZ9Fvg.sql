CREATE type ku$_type_attr_list_t
  as table of ku$_type_attr_t
/

