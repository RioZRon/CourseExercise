CREATE type sql_plan_table_type
                                                                      
as table of sql_plan_row_type
/

