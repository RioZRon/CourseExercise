CREATE type dm_nmf_feature_set
                                       as table of dm_nmf_feature
/

