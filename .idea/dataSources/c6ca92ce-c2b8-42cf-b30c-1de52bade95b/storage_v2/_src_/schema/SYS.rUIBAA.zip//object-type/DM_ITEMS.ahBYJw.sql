CREATE type dm_items
                                       as table of dm_item
/

