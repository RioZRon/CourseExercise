CREATE TYPE prvt_awr_inst_meta_tab
AS TABLE OF prvt_awr_inst_meta;
/

