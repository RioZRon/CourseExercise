CREATE TYPE     ku$_WorkerStatusList1010 AS TABLE OF sys.ku$_WorkerStatus1010
/

