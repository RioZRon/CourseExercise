CREATE VIEW V_$DIAG_INFO AS
  select "INST_ID","NAME","VALUE","CON_ID" from v$diag_info
/

