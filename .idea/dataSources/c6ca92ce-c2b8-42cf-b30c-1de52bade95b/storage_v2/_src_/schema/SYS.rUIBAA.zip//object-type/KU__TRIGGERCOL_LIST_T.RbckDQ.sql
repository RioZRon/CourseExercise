CREATE type ku$_triggercol_list_t
 as table of ku$_triggercol_t
/

