CREATE type ora_mining_tables_nt
                                       as
table of sys.ora_mining_table_type
/

