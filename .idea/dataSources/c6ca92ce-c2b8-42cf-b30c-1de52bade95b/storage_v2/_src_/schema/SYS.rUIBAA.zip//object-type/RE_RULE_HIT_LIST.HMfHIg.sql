CREATE TYPE     re$rule_hit_list
AS VARRAY(32000) OF sys.re$rule_hit
/

