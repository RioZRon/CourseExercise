CREATE VIEW USER_ANALYTIC_VIEW_CLASS AS
  select analytic_view_name, classification, value, language,
       order_num, origin_con_id
from NO_ROOT_SW_FOR_LOCAL(INT$DBA_AVIEW_CLASS)
where OWNER = SYS_CONTEXT('USERENV','CURRENT_USER')
/

