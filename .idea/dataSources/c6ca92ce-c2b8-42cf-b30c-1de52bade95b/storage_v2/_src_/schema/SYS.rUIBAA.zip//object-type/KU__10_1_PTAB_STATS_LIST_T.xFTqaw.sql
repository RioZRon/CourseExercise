CREATE type ku$_10_1_ptab_stats_list_t
  as table of ku$_10_1_tab_ptab_stats_t
/

