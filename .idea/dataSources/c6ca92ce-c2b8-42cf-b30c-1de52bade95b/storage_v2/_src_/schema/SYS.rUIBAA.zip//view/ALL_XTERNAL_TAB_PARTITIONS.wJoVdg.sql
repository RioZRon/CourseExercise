CREATE VIEW ALL_XTERNAL_TAB_PARTITIONS AS
  select u.name, o.name, o.subname, 'SYS', xt.default_dir,
       decode(xt.par_type, 1, 'BLOB', 2, 'CLOB',       'UNKNOWN'),
       case when xt.par_type = 2 then xt.param_clob else NULL end
from   sys.external_tab$ xt, sys.obj$ o, sys.tabpart$ tp, sys.user$ u,
       sys.tab$ t
where  o.obj# = xt.obj# and
       o.obj# = tp.obj# and
       u.user# = o.owner# and
       tp.bo# = t.obj# and
       o.namespace = 1 and o.remoteowner IS NULL and o.linkname IS NULL and
       (o.owner# = userenv('SCHEMAID')
        or tp.bo# in
            (select oa.obj#
             from sys.objauth$ oa
             where grantee# in ( select kzsrorol
                                 from x$kzsro
                               )
            )
        or /* user has system privileges */
         exists (select null from v$enabledprivs
                 where priv_number in (-45 /* LOCK ANY TABLE */,
                                       -47 /* SELECT ANY TABLE */,
                                       -397/* READ ANY TABLE */)
                 )
      )
union all -- COMPOSITE PARTITIONS
select u.name, o.name, o.subname, 'SYS', xt.default_dir,
       decode(xt.par_type, 1, 'BLOB', 2, 'CLOB',       'UNKNOWN'),
       case when xt.par_type = 2 then xt.param_clob else NULL end
from   sys.external_tab$ xt, sys.obj$ o, sys.tabcompart$ tcp, sys.user$ u,
       sys.tab$ t
where  o.obj# = xt.obj# and
       o.obj# = tcp.obj# and
       u.user# = o.owner# and
       tcp.bo# = t.obj# and
       o.namespace = 1 and o.remoteowner IS NULL and o.linkname IS NULL and
       (o.owner# = userenv('SCHEMAID')
        or tcp.bo# in
            (select oa.obj#
             from sys.objauth$ oa
             where grantee# in ( select kzsrorol
                                 from x$kzsro
                               )
            )
        or /* user has system privileges */
         exists (select null from v$enabledprivs
                 where priv_number in (-45 /* LOCK ANY TABLE */,
                                       -47 /* SELECT ANY TABLE */,
                                       -397/* READ ANY TABLE */)
                )
      )
/

