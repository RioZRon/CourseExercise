CREATE VIEW LOADER_DB_OPEN_READ_WRITE AS
  select count(*) from v$database where open_mode = 'READ WRITE'
/

