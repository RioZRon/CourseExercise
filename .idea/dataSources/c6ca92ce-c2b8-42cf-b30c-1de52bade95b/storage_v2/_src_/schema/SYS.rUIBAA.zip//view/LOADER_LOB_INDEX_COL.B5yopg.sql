CREATE VIEW LOADER_LOB_INDEX_COL AS
  select u.name as table_owner, o.name as table_name, c.name as column_name
     from sys.col$ c, sys.obj$ o, sys.user$ u, sys.icoldep$ i
     where o.owner# = u.user# and o.type# = 2 and c.obj# = o.obj# and
           c.type# in (112, 113) and i.bo# = o.obj# and i.intcol# = c.intcol#
           and bitand(c.property, 32) != 32
            and (o.owner# = userenv('schemaid')
                  or o.obj# in
                       (select oa.obj#
                        from sys.objauth$ oa
                        where grantee# in ( select kzsrorol
                                            from x$kzsro
                                          )
                       )
                  or
                     ora_check_SYS_privilege (o.owner#, o.type#) = 1
                 )
UNION ALL
  select u.name as table_owner, o.name as table_name, a.name as column_name
     from sys.attrcol$ a, sys.obj$ o, sys.user$ u, sys.icoldep$ i,
          sys.col$ c
     where o.owner# = u.user# and o.type# = 2 and c.obj# = o.obj# and
           c.type# in (112, 113) and i.bo# = o.obj# and i.intcol# = a.intcol#
           and c.intcol# = i.intcol# and a.obj# = o.obj#
            and (o.owner# = userenv('schemaid')
                  or o.obj# in
                       (select oa.obj#
                        from sys.objauth$ oa
                        where grantee# in ( select kzsrorol
                                            from x$kzsro
                                          )
                       )
                  or
                     ora_check_SYS_privilege (o.owner#, o.type#) = 1
                 )
UNION ALL
  select u.name as table_owner, o.name as table_name, a.name as column_name
     from sys.attrcol$ a, sys.obj$ o, sys.user$ u, sys.icol$ i, sys.col$ c,
          sys.ind$ x
     where o.owner# = u.user# and o.type# = 2 and c.obj# = o.obj# and
           c.type# in (112, 113) and i.bo# = o.obj# and i.intcol# = a.intcol#
           and c.intcol# = i.intcol# and a.obj# = o.obj# and x.bo# = o.obj#
           and x.type# = 9 and i.obj# = x.obj#
            and (o.owner# = userenv('schemaid')
                  or o.obj# in
                       (select oa.obj#
                        from sys.objauth$ oa
                        where grantee# in ( select kzsrorol
                                            from x$kzsro
                                          )
                       )
                  or
                     ora_check_SYS_privilege (o.owner#, o.type#) = 1
                 )
UNION ALL
  select u.name as table_owner, o.name as table_name, c.name as column_name
     from sys.obj$ o, sys.user$ u, sys.icol$ i, sys.col$ c, sys.ind$ x
     where o.owner# = u.user# and o.type# = 2 and c.obj# = o.obj# and
           c.type# in (112, 113) and i.bo# = o.obj# and i.intcol# = c.intcol#
           and bitand(c.property, 32) != 32 and x.bo# = o.obj#
           and x.type# = 9 and i.obj# = x.obj#
            and (o.owner# = userenv('schemaid')
                  or o.obj# in
                       (select oa.obj#
                        from sys.objauth$ oa
                        where grantee# in ( select kzsrorol
                                            from x$kzsro
                                          )
                       )
                  or
                     ora_check_SYS_privilege (o.owner#, o.type#) = 1
                 )
/

