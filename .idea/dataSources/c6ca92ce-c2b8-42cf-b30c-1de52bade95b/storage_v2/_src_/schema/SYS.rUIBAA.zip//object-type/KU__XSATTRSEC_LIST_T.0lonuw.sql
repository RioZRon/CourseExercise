CREATE type ku$_xsattrsec_list_t as table of ku$_xsattrsec_t;
/

