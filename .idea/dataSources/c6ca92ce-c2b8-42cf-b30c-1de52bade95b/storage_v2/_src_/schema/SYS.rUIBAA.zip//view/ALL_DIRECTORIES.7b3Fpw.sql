CREATE VIEW ALL_DIRECTORIES AS
  select OWNER, DIRECTORY_NAME, DIRECTORY_PATH, ORIGIN_CON_ID
from INT$DBA_DIRECTORIES
where ( OWNER = SYS_CONTEXT('USERENV', 'CURRENT_USER')
        or OBJ_ID(OWNER, DIRECTORY_NAME, OBJECT_TYPE#, OBJECT_ID) in
           (select oa.obj#
            from sys.objauth$ oa
            where grantee# in (select kzsrorol
                               from x$kzsro
                              )
           )
        or
          ora_check_sys_privilege (0, OBJECT_TYPE#) = 1
      )
/

