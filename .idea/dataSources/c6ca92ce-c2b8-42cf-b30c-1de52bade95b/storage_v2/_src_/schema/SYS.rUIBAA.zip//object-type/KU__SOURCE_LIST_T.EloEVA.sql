CREATE TYPE ku$_source_list_t AS TABLE OF sys.ku$_source_t;
/

