CREATE VIEW ALL_DB_LINKS AS
  select u.name, l.name, l.userid, l.host, l.ctime,
       decode(bitand(l.flag, 8), 8, 'YES', 'NO')
from sys.link$ l, sys.user$ u
where l.owner# in ( select kzsrorol from x$kzsro )
  and l.owner# = u.user#
/

