CREATE type dbms_xplan_type_table
  as table of dbms_xplan_type;
/

