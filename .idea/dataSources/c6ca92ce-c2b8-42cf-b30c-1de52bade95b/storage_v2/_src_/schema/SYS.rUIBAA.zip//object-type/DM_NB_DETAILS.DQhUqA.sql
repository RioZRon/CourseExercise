CREATE type dm_nb_details
                                       as table of dm_nb_detail
/

