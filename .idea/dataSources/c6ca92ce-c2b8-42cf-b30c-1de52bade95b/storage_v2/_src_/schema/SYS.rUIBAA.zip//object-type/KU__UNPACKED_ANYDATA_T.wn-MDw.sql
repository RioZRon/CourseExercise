CREATE TYPE     ku$_Unpacked_AnyData_t IS TABLE OF varchar2(2000);
/

