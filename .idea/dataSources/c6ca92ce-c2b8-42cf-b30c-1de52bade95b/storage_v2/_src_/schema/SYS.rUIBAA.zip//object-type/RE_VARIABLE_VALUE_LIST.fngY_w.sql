CREATE TYPE     re$variable_value_list
AS VARRAY(64000) OF sys.re$variable_value
/

