CREATE VIEW ALL_ENCRYPTED_COLUMNS AS
  select u.name, o.name, c.name,
          case e.ENCALG when 1 then '3 Key Triple DES 168 bits key'
                        when 2 then 'AES 128 bits key'
                        when 3 then 'AES 192 bits key'
                        when 4 then 'AES 256 bits key'
                        when 5 then 'ARIA 128 bits key'
                        when 6 then 'ARIA 192 bits key'
                        when 7 then 'ARIA 256 bits key'
                        when 8 then 'SEED 128 bits key'
                        when 9 then 'GOST 256 bits key'
                        else 'Internal Err'
          end,
          decode(bitand(c.property, 536870912), 0, 'YES', 'NO'),
          case e.INTALG when 1 then 'SHA-1'
                        when 2 then 'NOMAC'
                        else 'Internal Err'
          end
   from user$ u, obj$ o, col$ c, enc$ e
   where e.obj#=o.obj# and o.owner#=u.user# and bitand(flags, 128)=0 and
         e.obj#=c.obj# and bitand(c.property, 67108864) = 67108864 and
         (o.owner# = userenv('SCHEMAID')
          or
          e.obj# in (select obj# from sys.objauth$ where grantee# in
                        (select kzsrorol from x$kzsro))
          or
          /* user has system privileges */
          ora_check_sys_privilege ( o.owner#, o.type#) = 1
         )
/

