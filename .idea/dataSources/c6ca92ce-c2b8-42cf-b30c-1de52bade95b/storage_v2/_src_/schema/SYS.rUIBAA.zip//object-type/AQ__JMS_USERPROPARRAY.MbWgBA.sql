CREATE type aq$_jms_userproparray
                                      
as varray(100) of aq$_jms_userproperty;
/

