CREATE type ku$_outline_node_list_t
 as table of ku$_outline_node_t
/

