CREATE type ku$_audit_sys_priv_list_t
  as table of ku$_audit_sys_priv_t
/

