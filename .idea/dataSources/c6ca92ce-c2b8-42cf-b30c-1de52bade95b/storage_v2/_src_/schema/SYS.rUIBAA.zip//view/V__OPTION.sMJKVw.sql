CREATE VIEW V_$OPTION AS
  select "PARAMETER","VALUE","CON_ID" from v$option
/

