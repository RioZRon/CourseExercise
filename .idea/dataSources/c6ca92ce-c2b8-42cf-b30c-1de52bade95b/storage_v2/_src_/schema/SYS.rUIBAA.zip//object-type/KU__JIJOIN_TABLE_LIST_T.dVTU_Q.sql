CREATE type ku$_jijoin_table_list_t as table of  ku$_jijoin_table_t
/

