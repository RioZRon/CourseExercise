CREATE VIEW ALL_ATTRIBUTE_DIM_ATTR_CLASS AS
  select owner,
       dimension_name,
       attribute_name,
       classification,
       value,
       language,
       order_num,
       origin_con_id
from INT$DBA_ATTR_DIM_ATTR_CLASS
where OWNER = SYS_CONTEXT('USERENV', 'CURRENT_USER')
       or OWNER='PUBLIC'
       or OBJ_ID(OWNER, DIMENSION_NAME, OBJECT_TYPE, OBJECT_ID) in
            ( select obj#  -- directly granted privileges
              from sys.objauth$
              where grantee# in ( select kzsrorol from x$kzsro )
            )
       or ora_check_sys_privilege(owner_id, object_type) = 1
/

