CREATE type dm_nmf_attribute_set
                                       as table of dm_nmf_attribute
/

