CREATE type ku$_refcol_list_t
  as table of ku$_refcol_t
/

