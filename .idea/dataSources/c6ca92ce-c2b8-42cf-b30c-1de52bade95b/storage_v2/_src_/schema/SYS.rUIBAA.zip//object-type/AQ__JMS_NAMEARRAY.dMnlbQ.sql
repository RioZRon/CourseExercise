CREATE type aq$_jms_namearray
                                      
as varray(1024) of varchar(200);
/

