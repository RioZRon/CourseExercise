CREATE type     role_id_list as varray(10) of number
/

