CREATE type ku$_clstjoin_list_t as table of ku$_clstjoin_t
/

