CREATE TYPE  CanSyncRefArrayType AS VARRAY(256) OF
Sys.CanSyncRefMessage;
/

