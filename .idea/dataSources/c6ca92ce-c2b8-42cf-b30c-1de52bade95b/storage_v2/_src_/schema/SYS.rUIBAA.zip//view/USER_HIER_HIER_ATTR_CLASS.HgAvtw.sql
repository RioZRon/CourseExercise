CREATE VIEW USER_HIER_HIER_ATTR_CLASS AS
  select hier_name, HIER_ATTR_NAME, classification,
       value, language, order_num, origin_con_id
from NO_ROOT_SW_FOR_LOCAL(INT$DBA_HIER_HIER_ATTR_CLASS)
where owner = SYS_CONTEXT('USERENV','CURRENT_USER')
/

