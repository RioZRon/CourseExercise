CREATE VIEW GV_$PARALLEL_DEGREE_LIMIT_MTH AS
  select "INST_ID","NAME","CON_ID" from gv$parallel_degree_limit_mth
/

