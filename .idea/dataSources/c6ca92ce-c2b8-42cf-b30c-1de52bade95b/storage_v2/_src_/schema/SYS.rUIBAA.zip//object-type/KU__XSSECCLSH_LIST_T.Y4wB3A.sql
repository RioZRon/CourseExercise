CREATE type ku$_xssecclsh_list_t as table of ku$_xssecclsh_t;
/

