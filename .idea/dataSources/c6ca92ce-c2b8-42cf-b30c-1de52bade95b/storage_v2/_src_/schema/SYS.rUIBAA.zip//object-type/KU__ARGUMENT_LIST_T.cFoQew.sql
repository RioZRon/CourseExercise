CREATE type ku$_argument_list_t
   as table of ku$_argument_t
/

