CREATE TYPE     scheduler$_chain_link_list IS
 TABLE OF sys.scheduler$_chain_link
/

