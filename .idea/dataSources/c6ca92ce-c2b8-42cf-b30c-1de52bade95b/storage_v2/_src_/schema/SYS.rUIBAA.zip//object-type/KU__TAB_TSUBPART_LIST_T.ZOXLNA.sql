CREATE type ku$_tab_tsubpart_list_t as table of ku$_tab_tsubpart_t
/

