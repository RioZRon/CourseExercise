CREATE type ku$_hcs_av_cache_mlst_list_t
  as table of ku$_hcs_av_cache_mlst_t
/

