CREATE TYPE     re$table_alias_list
AS VARRAY(1024) OF sys.re$table_alias
/

