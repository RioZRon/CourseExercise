CREATE VIEW ALL_PLSQL_TYPE_ATTRS AS
  select u.name,
       t.typ_name || decode(bitand(t.properties,134217728),134217728,
                             '%ROWTYPE', null),
       o.name, a.name,
       decode(bitand(a.properties, 32768), 32768, 'REF',
              decode(bitand(a.properties, 16384), 16384, 'POINTER')),
       nvl2(a.synobj#, (select u.name from user$ u, "_CURRENT_EDITION_OBJ" o
            where o.owner#=u.user# and o.obj#=a.synobj#),
            decode(bitand(at.properties, 64), 64, null, au.name)),
       nvl2(a.synobj#, (select o.name from "_CURRENT_EDITION_OBJ" o
                        where o.obj#=a.synobj#),
            decode(at.typecode,
                   9, decode(a.charsetform, 2, 'NVARCHAR2', ao.name),
                   96, decode(a.charsetform, 2, 'NCHAR', ao.name),
                   112, decode(a.charsetform, 2, 'NCLOB', ao.name),
                   ao.name)),
       null,
       a.length, a.precision#, a.scale,
       decode(a.charsetform, 1, 'CHAR_CS',
                             2, 'NCHAR_CS',
                             3, NLS_CHARSET_NAME(a.charsetid),
                             4, 'ARG:'||a.charsetid),
       a.attribute#,
       decode(bitand(a.properties, 4096), 4096, 'C', 'B')
from sys.user$ u, sys."_CURRENT_EDITION_OBJ" o, sys.type$ t,
     sys.attribute$ a,
     sys."_CURRENT_EDITION_OBJ" ao, sys.user$ au, sys.type$ at
where bitand(t.properties, 64) != 64 -- u.name
  and o.owner# = u.user#
  and t.package_obj# IS NOT NULL                          -- only package types
  and o.obj# = t.package_obj#
  and o.subname IS NULL -- get the latest version only
  and o.type# <> 10 -- must not be invalid
  and bitand(t.properties, 2048) = 0 -- not system-generated
  and t.toid = a.toid
  and t.version# = a.version#
  and a.attr_toid = ao.oid$
  and ao.owner# = au.user#
  and a.attr_toid = at.toid
  and a.attr_version# = at.version#
  and (o.owner# = userenv('SCHEMAID')
       or
       o.obj# in (select oa.obj#
                  from sys.objauth$ oa
                  where grantee# in (select kzsrorol
                                     from x$kzsro))
       or /* user has system privileges */
       exists (select null from v$enabledprivs
               where priv_number in (-184 /* EXECUTE ANY TYPE */,
                                     -181 /* CREATE ANY TYPE */)))
UNION
--
-- Package type attributes in package types.
--
select u.name, t.typ_name, o.name, a.name, null,
       nvl2(a.synobj#, (select u.name
                        from user$ u, "_CURRENT_EDITION_OBJ" o
                        where o.owner#=u.user# and o.obj#=a.synobj#),
            au.name),
       at.typ_name || decode(bitand(at.properties,134217728),134217728,
                             '%ROWTYPE', null),
       nvl2(a.synobj#, (select o.name
                        from "_CURRENT_EDITION_OBJ" o
                        where o.obj#=a.synobj#),
            ao.name),
       a.length, a.precision#, a.scale,
       decode(a.charsetform, 1, 'CHAR_CS',
                             2, 'NCHAR_CS',
                             3, NLS_CHARSET_NAME(a.charsetid),
                             4, 'ARG:'||a.charsetid),
       a.attribute#,
       decode(bitand(a.properties, 4096), 4096, 'C', 'B')
from sys.user$ u, sys."_CURRENT_EDITION_OBJ" o, sys.type$ t,
     sys.attribute$ a,
     sys."_CURRENT_EDITION_OBJ" ao, sys.user$ au, sys.type$ at
where o.owner# = u.user#
  and t.package_obj# IS NOT NULL                          -- only package types
  and o.obj# = t.package_obj#
  and o.type# <> 10 -- must not be invalid
  and t.toid = a.toid
  and t.version# = a.version#
  and at.package_obj# IS NOT NULL
  and at.package_obj# = ao.obj#
  and ao.owner# = au.user#
  and a.attr_toid = at.toid
  and a.attr_version# = at.version#
  and (o.owner# = userenv('SCHEMAID')
       or
       o.obj# in (select oa.obj#
                  from sys.objauth$ oa
                  where grantee# in (select kzsrorol
                                     from x$kzsro))
       or /* user has system privileges */
       exists (select null from v$enabledprivs
               where priv_number in (-144 /* EXECUTE ANY PROCEDURE */,
                                     -141 /* CREATE ANY PROCEDURE */
                                     -241 /* DEBUG ANY PROCEDURE */)))
UNION
--
-- %rowtype attributes in package types.
--
select u.name,
       t.typ_name,
       o.name, a.name, null,
       nvl2(a.synobj#, (select u.name
                        from user$ u, "_CURRENT_EDITION_OBJ" o
                        where o.owner#=u.user# and o.obj#=a.synobj#),
            au.name),
       nvl2(a.synobj#, (select o.name
                        from "_CURRENT_EDITION_OBJ" o
                        where o.obj#=a.synobj#),
            ao.name) || '%ROWTYPE',
       null, null, null, null, null,
       a.attribute#, null
from sys.user$ u, sys."_CURRENT_EDITION_OBJ" o, sys.type$ t,
     sys.attribute$ a,
     sys."_CURRENT_EDITION_OBJ" ao, sys.user$ au, sys.oid$ id
where bitand(t.properties, 64) != 64 -- u.name
  and o.owner# = u.user#
  and t.package_obj# IS NOT NULL                          -- only package types
  and o.obj# = t.package_obj#
  and o.subname IS NULL -- get the latest version only
  and o.type# <> 10 -- must not be invalid
  and bitand(t.properties, 2048) = 0 -- not system-generated
  and t.toid = a.toid
  and t.version# = a.version#
  and a.attr_toid = id.oid$
  and id.obj# = ao.obj#
  and ao.type# in (2,4)                     -- table or view collection element
  and ao.owner# = au.user#
  and (o.owner# = userenv('SCHEMAID')
       or
       o.obj# in (select oa.obj#
                  from sys.objauth$ oa
                  where grantee# in (select kzsrorol
                                     from x$kzsro))
       or /* user has system privileges */
       exists (select null from v$enabledprivs
               where priv_number in (-184 /* EXECUTE ANY TYPE */,
                                     -181 /* CREATE ANY TYPE */)))
/

