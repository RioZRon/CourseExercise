CREATE type dbms_cube_util_dflt_msr_t
  as table of dbms_cube_util_dflt_msr_r
/

