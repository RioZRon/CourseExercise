CREATE type dm_conditionals
                                       as table of dm_conditional
/

