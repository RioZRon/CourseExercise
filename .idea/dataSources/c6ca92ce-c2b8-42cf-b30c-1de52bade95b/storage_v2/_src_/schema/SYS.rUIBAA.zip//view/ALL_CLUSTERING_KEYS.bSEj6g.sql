CREATE VIEW ALL_CLUSTERING_KEYS AS
  select k.owner, k.table_name, k.detail_owner, k.detail_name, k.detail_column,
       k.position, k.groupid
from   DBA_CLUSTERING_KEYS k, ALL_TABLES t
WHERE  k.OWNER = t.OWNER
AND    k.TABLE_NAME = t.TABLE_NAME
/

