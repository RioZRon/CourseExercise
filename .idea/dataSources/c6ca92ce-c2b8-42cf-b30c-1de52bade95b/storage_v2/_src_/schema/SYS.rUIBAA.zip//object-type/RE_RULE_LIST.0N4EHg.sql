CREATE TYPE     re$rule_list
AS VARRAY(1024) OF varchar2(65)
 alter type     re$rule_list modify element type varchar2(261)
           CASCADE
/

