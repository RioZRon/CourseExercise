CREATE type dm_histograms
                                       as table of dm_histogram_bin
/

