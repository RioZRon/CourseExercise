CREATE type ku$_rls_assoc_list_t
  as table of ku$_rls_associations_t;
/

