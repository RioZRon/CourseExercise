CREATE VIEW ALL_SQL_TRANSLATIONS AS
  select u.name, o.name, s.sqltext, s.txltext, s.sqlid, s.sqlhash,
       decode(bitand(s.flags, 1), 1, 'TRUE', 0, 'FALSE'),
       s.rtime, s.cinfo, s.module, s.action, s.puser#, s.pschema#, s.comment$,
       s.errcode#,
       decode(s.errsrc, 1, 'TRANSLATE', 2, 'PARSE', 3, 'EXECUTE'),
       decode(s.txlmthd, 1, 'TRANSLATOR', 2, 'DICTIONARY'),
       s.dictid
  from sys.sqltxl_sql$ s, sys."_CURRENT_EDITION_OBJ" o, sys.user$ u
 where s.obj# = o.obj# and
       o.owner# = u.user# and
       (
         o.owner# = userenv('SCHEMAID')
         or
         exists (select null from sys.objauth$ oa
                  where oa.obj# = o.obj#
                    and oa.grantee# in (select kzsrorol from x$kzsro)
                    and oa.privilege# in (0 /* ALTER */, 29 /* USE */))
         or
         exists (select null from v$enabledprivs
                 where priv_number in (
                                -335 /* CREATE ANY SQL TRANSLATION PROFILE */,
                                -336 /* ALTER ANY SQL TRANSLATION PROFILE  */,
                                -337 /* USE ANY SQL TRANSLATION PROFILE    */,
                                -338 /* DROP ANY SQL TRANSLATION PROFILE   */
                                      )
                )
       )
/

