CREATE VIEW ALL_HIER_HIER_ATTRIBUTES AS
  select owner,
       hier_name,
       HIER_ATTR_NAME,
       EXPRESSION,
       ORDER_NUM,
       origin_con_id
from INT$DBA_HIER_HIER_ATTRIBUTES
where OWNER = SYS_CONTEXT('USERENV', 'CURRENT_USER')
       or OWNER='PUBLIC'
       or OBJ_ID(OWNER, HIER_NAME, OBJECT_TYPE, OBJECT_ID) in
            ( select obj#  -- directly granted privileges
              from sys.objauth$
              where grantee# in ( select kzsrorol from x$kzsro )
            )
       or ora_check_sys_privilege(owner_id, object_type) = 1
/

