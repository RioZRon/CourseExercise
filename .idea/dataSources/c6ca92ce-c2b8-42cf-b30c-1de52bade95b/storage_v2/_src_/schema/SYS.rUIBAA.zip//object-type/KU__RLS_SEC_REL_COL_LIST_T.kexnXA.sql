CREATE type ku$_rls_sec_rel_col_list_t
  as table of ku$_rls_sec_rel_col_t;
/

