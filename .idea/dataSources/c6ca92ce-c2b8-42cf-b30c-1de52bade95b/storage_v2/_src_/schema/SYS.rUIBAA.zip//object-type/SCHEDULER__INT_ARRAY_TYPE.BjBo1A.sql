CREATE TYPE scheduler$_int_array_type IS VARRAY (1000) OF INTEGER
/

