CREATE VIEW ALL_PLSQL_COLL_TYPES AS
  select u.name,
       c.coll_name,
       o.name,
       decode(bitand(c.properties, 2097152), 2097152, 'PL/SQL INDEX TABLE',
              decode(bitand(c.properties, 4194304), 4194304,
                     'PL/SQL INDEX TABLE', co.name)),
       c.upper_bound,
       nvl2(c.synobj#, (select u.name from user$ u, "_CURRENT_EDITION_OBJ" o
            where o.owner#=u.user# and o.obj#=c.synobj#),
            decode(bitand(et.properties, 64), 64, null, eu.name)),
       nvl2(c.synobj#, (select o.name from "_CURRENT_EDITION_OBJ" o
                        where o.obj#=c.synobj#),
            decode(et.typecode,
                   9, decode(c.charsetform, 2, 'NVARCHAR2', eo.name),
                   96, decode(c.charsetform, 2, 'NCHAR', eo.name),
                   112, decode(c.charsetform, 2, 'NCLOB', eo.name),
                   eo.name)),
       null,
       c.length,
       c.precision,
       c.scale,
       decode(c.charsetform, 1, 'CHAR_CS',
                             2, 'NCHAR_CS',
                             3, NLS_CHARSET_NAME(c.charsetid),
                             4, 'ARG:'||c.charsetid),
       decode(bitand(c.properties, 131072), 131072, 'FIXED',
              decode(bitand(c.properties, 262144), 262144, 'VARYING')),
       decode(bitand(c.properties, 65536), 65536, 'NO', 'YES'),
       decode(bitand(c.properties, 4096), 4096, 'C', 'B'),
       decode(bitand(c.properties, 2097152), 2097152, 'BINARY_INTEGER',
              decode(bitand(c.properties, 4194304), 4194304, 'VARCHAR2')),
       decode(bitand(c.properties, 32768), 32768, 'REF',
              decode(bitand(c.properties, 16384), 16384, 'POINTER'))
from sys.user$ u, sys."_CURRENT_EDITION_OBJ" o, sys.collection$ c,
     sys."_CURRENT_EDITION_OBJ" co, sys."_CURRENT_EDITION_OBJ" eo,
     sys.user$ eu, sys.type$ et
where c.package_obj# IS NOT NULL                          -- only package types
  and o.obj# = c.package_obj#
  and o.owner# = u.user#
  and o.subname IS NULL -- only the most recent version
  and o.type# <> 10 -- must not be invalid
  and c.coll_toid = co.oid$
  and c.elem_toid = eo.oid$
  and eo.owner# = eu.user#
  and c.elem_toid = et.tvoid
  and (o.owner# = userenv('SCHEMAID')
       or
       o.obj# in (select oa.obj#
                  from sys.objauth$ oa
                  where grantee# in (select kzsrorol
                                     from x$kzsro))
       or /* user has system privileges */
       exists (select null from v$enabledprivs
               where priv_number in (-184 /* EXECUTE ANY TYPE */,
                                     -181 /* CREATE ANY TYPE */)))
UNION
--
-- Package collection types with package level element types
--
select u.name,
       c.coll_name,
       o.name,
       decode(bitand(c.properties, 2097152), 2097152, 'PL/SQL INDEX TABLE',
              decode(bitand(c.properties, 4194304), 4194304,
                     'PL/SQL INDEX TABLE', co.name)),
       c.upper_bound,
       nvl2(c.synobj#, (select u.name from user$ u, "_CURRENT_EDITION_OBJ" o
            where o.owner#=u.user# and o.obj#=c.synobj#), eu.name),
       et.typ_name || decode(bitand(et.properties,134217728),134217728,
                                    '%ROWTYPE', null),
       nvl2(c.synobj#, (select o.name from "_CURRENT_EDITION_OBJ" o
                        where o.obj#=c.synobj#), eo.name),
       c.length,
       c.precision,
       c.scale,
       decode(c.charsetform, 1, 'CHAR_CS',
                             2, 'NCHAR_CS',
                             3, NLS_CHARSET_NAME(c.charsetid),
                             4, 'ARG:'||c.charsetid),
       decode(bitand(c.properties, 131072), 131072, 'FIXED',
              decode(bitand(c.properties, 262144), 262144, 'VARYING')),
       decode(bitand(c.properties, 65536), 65536, 'NO', 'YES'),
       decode(bitand(c.properties, 4096), 4096, 'C', 'B'),
       decode(bitand(c.properties, 2097152), 2097152, 'BINARY_INTEGER',
              decode(bitand(c.properties, 4194304), 4194304, 'VARCHAR2')),
       null
from sys.user$ u, sys."_CURRENT_EDITION_OBJ" o, sys.collection$ c,
     sys."_CURRENT_EDITION_OBJ" co,
     sys."_CURRENT_EDITION_OBJ" eo, sys.user$ eu, sys.type$ et
where c.package_obj# IS NOT NULL                          -- only package types
  and o.obj# = c.package_obj#
  and o.owner# = u.user#
  and o.type# <> 10 -- must not be invalid
  and c.coll_toid = co.oid$
  and et.package_obj# IS NOT NULL
  and et.package_obj# = eo.obj#
  and eo.owner# = eu.user#
  and c.elem_toid = et.toid
  and (o.owner# = userenv('SCHEMAID')
       or
       o.obj# in (select oa.obj#
                  from sys.objauth$ oa
                  where grantee# in (select kzsrorol
                                     from x$kzsro))
       or /* user has system privileges */
       exists (select null from v$enabledprivs
               where priv_number in (-144 /* EXECUTE ANY PROCEDURE */,
                                     -141 /* CREATE ANY PROCEDURE */
                                     -241 /* DEBUG ANY PROCEDURE */)))
UNION
--
-- Package collection types with table/view rowtypes
--
select u.name,
       c.coll_name,
       o.name,
       decode(bitand(c.properties, 2097152), 2097152, 'PL/SQL INDEX TABLE',
              decode(bitand(c.properties, 4194304), 4194304,
                     'PL/SQL INDEX TABLE', co.name)),
       c.upper_bound,
       nvl2(c.synobj#, (select u.name
                        from user$ u, "_CURRENT_EDITION_OBJ" o
                        where o.owner#=u.user# and o.obj#=c.synobj#),
            eu.name),
       nvl2(c.synobj#, (select o.name
                        from "_CURRENT_EDITION_OBJ" o
                        where o.obj#=c.synobj#),
             eo.name) || '%ROWTYPE',
       null, null, null, null, null,
       decode(bitand(c.properties, 131072), 131072, 'FIXED',
              decode(bitand(c.properties, 262144), 262144, 'VARYING')),
       decode(bitand(c.properties, 65536), 65536, 'NO', 'YES'),
       decode(bitand(c.properties, 4096), 4096, 'C', 'B'),
       decode(bitand(c.properties, 2097152), 2097152, 'BINARY_INTEGER',
              decode(bitand(c.properties, 4194304), 4194304, 'VARCHAR2')),
       decode(bitand(c.properties, 32768), 32768, 'REF',
              decode(bitand(c.properties, 16384), 16384, 'POINTER'))
from sys.user$ u, sys."_CURRENT_EDITION_OBJ" o, sys.collection$ c,
     sys."_CURRENT_EDITION_OBJ" co, sys."_CURRENT_EDITION_OBJ" eo,
     sys.user$ eu, sys.oid$ id
where c.package_obj# IS NOT NULL                          -- only package types
  and o.obj# = c.package_obj#
  and o.owner# = u.user#
  and o.subname IS NULL -- only the most recent version
  and o.type# <> 10 -- must not be invalid
  and c.coll_toid = co.oid$
  and c.elem_toid = id.oid$
  and id.obj# = eo.obj#
  and eo.type# in (2,4)                     -- table or view collection element
  and eo.owner# = eu.user#
  and (o.owner# = userenv('SCHEMAID')
       or
       o.obj# in (select oa.obj#
                  from sys.objauth$ oa
                  where grantee# in (select kzsrorol
                                     from x$kzsro))
       or /* user has system privileges */
       exists (select null from v$enabledprivs
               where priv_number in (-184 /* EXECUTE ANY TYPE */,
                                     -181 /* CREATE ANY TYPE */)))
/

