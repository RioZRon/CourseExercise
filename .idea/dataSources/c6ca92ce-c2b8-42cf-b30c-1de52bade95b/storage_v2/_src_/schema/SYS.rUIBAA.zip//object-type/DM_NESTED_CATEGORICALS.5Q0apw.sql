CREATE type dm_nested_categoricals
                                      
  as table of dm_nested_categorical
/

