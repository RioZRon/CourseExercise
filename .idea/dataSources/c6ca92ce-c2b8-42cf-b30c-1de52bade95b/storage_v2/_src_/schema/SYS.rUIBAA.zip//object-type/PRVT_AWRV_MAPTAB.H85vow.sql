CREATE TYPE prvt_awrv_mapTab AS TABLE OF prvt_awrv_map;
/

