CREATE TYPE     aq$_ntfn_msgid_array
AS VARRAY(1073741824) OF raw(16);
/

