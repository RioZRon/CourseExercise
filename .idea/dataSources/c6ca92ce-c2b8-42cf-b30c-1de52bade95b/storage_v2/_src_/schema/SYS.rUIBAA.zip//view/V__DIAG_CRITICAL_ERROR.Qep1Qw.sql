CREATE VIEW V_$DIAG_CRITICAL_ERROR AS
  select "FACILITY","ERROR","CON_ID" from v$diag_critical_error
/

