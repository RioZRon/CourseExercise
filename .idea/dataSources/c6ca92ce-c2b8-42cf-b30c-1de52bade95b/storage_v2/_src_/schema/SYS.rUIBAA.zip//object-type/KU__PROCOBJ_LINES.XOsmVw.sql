CREATE TYPE     ku$_procobj_lines AS TABLE OF sys.ku$_procobj_line
/

