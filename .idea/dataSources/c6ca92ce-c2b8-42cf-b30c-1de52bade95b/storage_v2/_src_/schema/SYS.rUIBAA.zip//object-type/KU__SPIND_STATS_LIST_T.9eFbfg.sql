CREATE type ku$_spind_stats_list_t
  as table of ku$_spind_stats_t
/

