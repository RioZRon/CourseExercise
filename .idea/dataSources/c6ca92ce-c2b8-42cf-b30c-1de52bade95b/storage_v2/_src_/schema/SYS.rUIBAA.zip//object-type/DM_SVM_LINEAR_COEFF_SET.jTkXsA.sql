CREATE type dm_svm_linear_coeff_set
                                       as table of dm_svm_linear_coeff
/

