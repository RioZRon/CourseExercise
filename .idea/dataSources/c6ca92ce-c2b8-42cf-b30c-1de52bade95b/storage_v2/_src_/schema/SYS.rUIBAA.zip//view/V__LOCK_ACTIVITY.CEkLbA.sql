CREATE VIEW V_$LOCK_ACTIVITY AS
  select "FROM_VAL","TO_VAL","ACTION_VAL","COUNTER","CON_ID" from v$lock_activity
/

