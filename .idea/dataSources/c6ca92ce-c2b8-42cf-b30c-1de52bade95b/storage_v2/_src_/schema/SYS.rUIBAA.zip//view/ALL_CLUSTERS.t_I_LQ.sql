CREATE VIEW ALL_CLUSTERS AS
  select OWNER, CLUSTER_NAME, TABLESPACE_NAME,
          PCT_FREE, PCT_USED, KEY_SIZE,
          INI_TRANS, MAX_TRANS,
          INITIAL_EXTENT, NEXT_EXTENT,
          MIN_EXTENTS, MAX_EXTENTS, PCT_INCREASE,
          FREELISTS, FREELIST_GROUPS,
          AVG_BLOCKS_PER_KEY,
          CLUSTER_TYPE, FUNCTION, HASHKEYS,
          DEGREE, INSTANCES, CACHE, BUFFER_POOL, FLASH_CACHE,
          CELL_FLASH_CACHE, SINGLE_TABLE, DEPENDENCIES
from INT$DBA_CLUSTERS
where (OWNER = SYS_CONTEXT('USERENV', 'CURRENT_USER')
       or  /* user has system privileges */
       (
        /* 3 is the type# for CLUSTER. See kgl.h for more info */
        ora_check_sys_privilege ( ownerid, 3 ) = 1
       )
      )
/

