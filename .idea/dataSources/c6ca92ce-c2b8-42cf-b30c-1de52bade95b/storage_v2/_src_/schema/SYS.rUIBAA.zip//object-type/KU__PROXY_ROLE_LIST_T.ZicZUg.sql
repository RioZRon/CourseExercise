CREATE type ku$_proxy_role_list_t as TABLE of ku$_proxy_role_item_t
/

