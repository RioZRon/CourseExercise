CREATE VIEW ALL_ANALYTIC_VIEW_DIMENSIONS AS
  select OWNER,
       ANALYTIC_VIEW_NAME,
       DIMENSION_OWNER,
       DIMENSION_NAME,
       DIMENSION_ALIAS,
       --DECODE(avd.leaves_only, 1, 'LEAVES ONLY') LEAVES_ONLY,
       DIMENSION_TYPE,
       ALL_MEMBER_NAME,
       ALL_MEMBER_CAPTION,
       ALL_MEMBER_DESCRIPTION,
       ORDER_NUM,
       ORIGIN_CON_ID
from INT$DBA_AVIEW_DIMENSIONS
where OWNER = SYS_CONTEXT('USERENV', 'CURRENT_USER')
       or OWNER='PUBLIC'
       or OBJ_ID(OWNER, ANALYTIC_VIEW_NAME, OBJECT_TYPE, OBJECT_ID) in
            ( select obj#  -- directly granted privileges
              from sys.objauth$
              where grantee# in ( select kzsrorol from x$kzsro )
            )
       or ora_check_sys_privilege(owner_id, object_type) = 1
/

