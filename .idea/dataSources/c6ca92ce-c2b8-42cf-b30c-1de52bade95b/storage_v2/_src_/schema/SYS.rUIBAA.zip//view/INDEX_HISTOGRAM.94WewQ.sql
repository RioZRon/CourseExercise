CREATE VIEW INDEX_HISTOGRAM AS
  select hist.indx * power(2, stats.kdxstscl-4)  repeat_count,
        hist.kdxhsval                           keys_with_repeat_count
        from  x$kdxst stats, x$kdxhs hist
/

