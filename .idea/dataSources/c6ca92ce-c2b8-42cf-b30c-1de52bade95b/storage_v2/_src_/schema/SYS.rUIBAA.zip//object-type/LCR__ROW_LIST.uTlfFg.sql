CREATE TYPE lcr$_row_list AS TABLE OF sys.lcr$_row_unit;
/

