CREATE type ku$_ind_compart_list_t as table of ku$_ind_compart_t
/

