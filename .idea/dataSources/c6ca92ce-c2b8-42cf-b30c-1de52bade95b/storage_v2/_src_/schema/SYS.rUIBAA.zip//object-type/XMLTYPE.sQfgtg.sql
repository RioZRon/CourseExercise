CREATE type XMLType                                       
  authid current_user as opaque varying (*)
 using library xmltype_lib
(
  -- creates the XML data
  static function createXML (xmlData IN clob) return sys.XMLType deterministic parallel_enable,
  static function createXML (xmlData IN varchar2) return sys.XMLType deterministic parallel_enable,

  -- extract function
  member function extract(xpath IN varchar2) return sys.XMLType deterministic parallel_enable,

  -- existsNode function
  member function existsNode(xpath IN varchar2) return number deterministic parallel_enable,

  -- is it a fragment?
  member function isFragment return number deterministic parallel_enable,

  -- extraction functions..!
  -- do we want the encoding to be specified in the result or not ..?
  member function getClobVal return CLOB deterministic parallel_enable,
  member function getStringVal return varchar2 deterministic parallel_enable,
  member function getNumberVal return number deterministic parallel_enable

)
 alter type     XMLType add
  member function getBlobVal(csid IN number) return BLOB deterministic
 alter type     XMLType add
  STATIC FUNCTION createXML (xmlData IN clob, schema IN varchar2,
                 validated IN number := 0, wellformed IN number := 0)
                 return sys.XMLType deterministic parallel_enable
 alter type     XMLType add
  STATIC FUNCTION createXML (xmlData IN blob, csid IN number,
                 schema IN varchar2,
                 validated IN number := 0, wellformed IN number := 0)
                 return sys.XMLType deterministic parallel_enable
 alter type     XMLType add
  STATIC FUNCTION createXML (xmlData IN bfile, csid IN number,
                 schema IN varchar2,
                 validated IN number := 0, wellformed IN number := 0)
                 return sys.XMLType deterministic parallel_enable
 alter type     XMLType add
  STATIC FUNCTION createXML (xmlData IN varchar2, schema IN varchar2,
                 validated IN number := 0, wellformed IN number := 0)
                 return sys.XMLType deterministic parallel_enable
 alter type     XMLType add
  STATIC FUNCTION createXML (xmlData IN "<ADT_1>",
                 schema IN varchar2 := NULL, element IN varchar2 := NULL,
                 validated IN NUMBER := 0)
    return sys.XMLType deterministic parallel_enable
 alter type     XMLType add
  STATIC FUNCTION createXML (xmlData IN SYS_REFCURSOR,
                 schema in varchar2 := NULL, element in varchar2 := NULL,
                 validated in number := 0)
     return sys.XMLType deterministic parallel_enable
 alter type     XMLType add
  STATIC FUNCTION createXML (xmlData IN AnyData,
                 schema in varchar2 := NULL, element in varchar2 := NULL,
                 validated in number := 0)
     return sys.XMLType deterministic parallel_enable
 alter type     XMLType add
  MEMBER FUNCTION extract(xpath IN varchar2, nsmap IN VARCHAR2)
    return sys.XMLType deterministic parallel_enable
 alter type     XMLType add
  MEMBER FUNCTION existsNode(xpath in varchar2, nsmap in varchar2)
    return number deterministic parallel_enable
 alter type     XMLType add
  member function transform(xsl IN sys.XMLType,
                                parammap in varchar2 := NULL)
    return sys.XMLType deterministic parallel_enable
 alter type     XMLType add
  member function getClobVal(pflag IN number, indent IN number) return CLOB deterministic parallel_enable
 alter type     XMLType add
  member function getBlobVal(csid IN number, pflag IN number, indent IN number) return BLOB deterministic parallel_enable
 alter type     XMLType add
  member function getStringVal(pflag IN number, indent IN number) return varchar2 deterministic parallel_enable
 alter type     XMLType add
  MEMBER PROCEDURE toObject(SELF in sys.XMLType, object OUT "<ADT_1>",
                                schema in varchar2 := NULL,
                                element in varchar2 := NULL)
 alter type     XMLType add
  MEMBER FUNCTION isSchemaBased return number deterministic parallel_enable
 alter type     XMLType add
  MEMBER FUNCTION getSchemaURL return varchar2 deterministic parallel_enable
 alter type     XMLType add
  MEMBER FUNCTION getSchemaId return raw deterministic parallel_enable
 alter type     XMLType add
  MEMBER FUNCTION getRootElement return varchar2 deterministic parallel_enable
 alter type     XMLType add
  MEMBER FUNCTION createSchemaBasedXML(schema IN varchar2 := NULL)
     return sys.XMLType deterministic parallel_enable
 alter type     XMLType add
  MEMBER FUNCTION createNonSchemaBasedXML return sys.XMLType deterministic parallel_enable
 alter type     XMLType add
  member function getNamespace return varchar2 deterministic parallel_enable
 alter type     XMLType add
  member procedure schemaValidate(self IN OUT NOCOPY XMLType)
 alter type     XMLType add
  member function isSchemaValidated return NUMBER deterministic parallel_enable
 alter type     XMLType add
  member procedure setSchemaValidated(self IN OUT NOCOPY XMLType,
                                      flag IN BINARY_INTEGER := 1)
 alter type     XMLType add
  member function isSchemaValid(schurl IN VARCHAR2 := NULL,
                         elem IN VARCHAR2 := NULL) return NUMBER
                         deterministic parallel_enable
 alter type     XMLType add
  member function insertXMLBefore(xpath IN VARCHAR2, value_expr IN XMLType,
           namespace IN VARCHAR2 := NULL) return XMLType
           deterministic parallel_enable
 alter type     XMLType add
  member function appendChildXML(xpath IN VARCHAR2, value_expr IN XMLType,
         namespace IN VARCHAR2 := NULL) return XMLType
         deterministic parallel_enable
 alter type     XMLType add
  member function deleteXML(xpath IN VARCHAR2, namespace IN VARCHAR2 := NULL)
         return XMLType deterministic parallel_enable
 alter type     XMLType add
  constructor function XMLType(xmlData IN clob, schema IN varchar2 := NULL,
                validated IN number := 0, wellformed IN number := 0)
    return self as result deterministic parallel_enable
 alter type     XMLType add
  constructor function XMLType(xmlData IN blob, csid IN number,
                               schema IN varchar2 := NULL,
                validated IN number := 0, wellformed IN number := 0)
    return self as result deterministic parallel_enable
 alter type     XMLType add
  constructor function XMLType(xmlData IN bfile, csid IN number,
                               schema IN varchar2 := NULL,
                validated IN number := 0, wellformed IN number := 0)
    return self as result deterministic parallel_enable
 alter type     XMLType add
  constructor function XMLType(xmlData IN varchar2, schema IN varchar2 := NULL
                , validated IN number := 0, wellformed IN number := 0)
    return self as result deterministic parallel_enable
 alter type     XMLType add
  constructor function XMLType (xmlData IN "<ADT_1>",
                schema IN varchar2 := NULL, element IN varchar2 := NULL,
                validated IN number := 0)
    return self as result deterministic parallel_enable
 alter type     XMLType add
  constructor function XMLType (xmlData IN AnyData,
                schema IN varchar2 := NULL, element IN varchar2 := NULL,
                validated IN number := 0)
    return self as result deterministic parallel_enable
 alter type     XMLType add
  constructor function XMLType(xmlData IN SYS_REFCURSOR,
                schema in varchar2 := NULL, element in varchar2 := NULL,
                validated in number := 0)
    return self as result deterministic parallel_enable
 alter type     XMLType add
  STATIC FUNCTION createXMLFromBinary (xmlData IN blob)
                 return sys.XMLType deterministic parallel_enable
/

