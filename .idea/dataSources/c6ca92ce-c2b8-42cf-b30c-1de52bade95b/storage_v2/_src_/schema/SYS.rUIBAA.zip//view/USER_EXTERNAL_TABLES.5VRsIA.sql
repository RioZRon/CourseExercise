CREATE VIEW USER_EXTERNAL_TABLES AS
  select o.name, 'SYS', xt.type$, 'SYS', xt.default_dir,
       decode(xt.reject_limit, 2147483647, 'UNLIMITED', xt.reject_limit),
       decode(xt.par_type, 1, 'BLOB', 2, 'CLOB',       'UNKNOWN'),
       case when xt.par_type = 2 then xt.param_clob else NULL end,
       decode(bitand(xt.property, 3), 2, 'REFERENCED', 1, 'ALL',     'UNKNOWN')
from sys.external_tab$ xt, sys.obj$ o
where o.owner# = userenv('SCHEMAID')
  and o.subname IS NULL
  and o.obj# = xt.obj#
/

