CREATE type dbms_cube_util_ext_md_t
  as table of dbms_cube_util_ext_md_r
/

