CREATE type ku$_constraint0_list_t as table of ku$_constraint0_t;
/

