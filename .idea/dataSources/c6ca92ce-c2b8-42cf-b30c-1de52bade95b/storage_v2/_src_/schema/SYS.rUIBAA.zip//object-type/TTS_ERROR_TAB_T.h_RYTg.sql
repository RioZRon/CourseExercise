CREATE TYPE tts_error_tab_t IS TABLE OF tts_error_t;
/

