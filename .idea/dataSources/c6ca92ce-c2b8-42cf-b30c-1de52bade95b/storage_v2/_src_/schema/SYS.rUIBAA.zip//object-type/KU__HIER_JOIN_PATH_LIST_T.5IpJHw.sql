CREATE type ku$_hier_join_path_list_t
   as table of ku$_hier_join_path_t
/

