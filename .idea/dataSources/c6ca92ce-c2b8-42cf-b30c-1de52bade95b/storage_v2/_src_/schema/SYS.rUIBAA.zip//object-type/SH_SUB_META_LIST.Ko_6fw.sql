CREATE TYPE     sh$sub_meta_list AS VARRAY(1024) OF sys.sh$sub_meta;
/

