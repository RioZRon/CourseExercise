CREATE type ku$_pind_stats_list_t
  as table of ku$_pind_stats_t
/

