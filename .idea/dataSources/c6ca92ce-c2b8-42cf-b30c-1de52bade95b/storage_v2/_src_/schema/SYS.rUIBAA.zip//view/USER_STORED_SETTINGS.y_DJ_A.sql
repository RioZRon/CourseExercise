CREATE VIEW USER_STORED_SETTINGS AS
  SELECT object_name, object_id, object_type, param_name, param_value,
       origin_con_id
  from NO_ROOT_SW_FOR_LOCAL(int$dba_stored_settings)
 where OWNER = SYS_CONTEXT('USERENV', 'CURRENT_USER')
/

