CREATE TYPE scheduler_filewatcher_res_list AS
  TABLE OF scheduler_filewatcher_result
/

