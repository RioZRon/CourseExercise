CREATE TYPE ket$_window_list IS TABLE OF ket$_window_type
/

