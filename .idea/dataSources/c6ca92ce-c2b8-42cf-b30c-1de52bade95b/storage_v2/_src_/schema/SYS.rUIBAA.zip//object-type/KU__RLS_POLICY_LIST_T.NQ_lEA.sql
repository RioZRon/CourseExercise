CREATE type ku$_rls_policy_list_t as table of ku$_rls_policy_t;
/

