CREATE type ku$_xsinstinhkey_list_t as table of ku$_xsinst_inhkey_t;
/

