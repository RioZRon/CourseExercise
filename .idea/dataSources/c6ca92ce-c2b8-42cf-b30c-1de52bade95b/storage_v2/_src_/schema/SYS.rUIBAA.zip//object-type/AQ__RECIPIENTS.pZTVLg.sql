CREATE TYPE     aq$_recipients
                                                                      
AS VARRAY(1024) OF sys.aq$_agent
/

