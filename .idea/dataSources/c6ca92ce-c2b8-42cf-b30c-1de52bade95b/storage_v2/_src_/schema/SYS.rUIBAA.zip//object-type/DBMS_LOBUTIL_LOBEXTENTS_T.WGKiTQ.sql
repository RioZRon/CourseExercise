CREATE TYPE dbms_lobutil_lobextents_t
    AS
    TABLE OF dbms_lobutil_lobextent_t;
/

