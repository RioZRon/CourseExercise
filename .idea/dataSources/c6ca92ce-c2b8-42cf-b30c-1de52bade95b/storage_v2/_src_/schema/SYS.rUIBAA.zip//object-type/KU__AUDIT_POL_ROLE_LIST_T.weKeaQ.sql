CREATE type ku$_audit_pol_role_list_t
  as table of ku$_audit_pol_role_t
/

