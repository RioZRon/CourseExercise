CREATE VIEW ALL_LOBS AS
  select u.name, o.name,
       decode(bitand(c.property, 1), 1, ac.name, c.name), lo.name,
       decode(bitand(l.property, 8),
           8, decode(l.ts#, 2147483647, ts1.name, ts.name), ts.name),
       io.name,
       l.chunk * decode(bitand(l.property, 8), 8, ts1.blocksize,
                        ts.blocksize),
       decode(bitand(l.flags, 32), 0, l.pctversion$, to_number(NULL)),
       decode(bitand(l.flags, 32), 32,
              decode(bitand(l.property, 2048), 2048, to_number(NULL),
                     l.retention), to_number(NULL)),
       decode(l.freepools, 0, to_number(NULL), 65534, to_number(NULL),
              65535, to_number(NULL), l.freepools),
       decode(bitand(l.flags, 795), 1, 'NO', 2, 'NO', 8, 'CACHEREADS',
                                   16, 'CACHEREADS', 256, 'YES', 512, 'YES',
                                    'YES'),
       decode(bitand(l.flags, 786), 2, 'NO', 16, 'NO', 256, 'NO', 512, 'YES',
                                    'YES'),
       decode(bitand(l.flags, 4096), 4096, 'YES',
              decode(bitand(l.property, 2048), 2048, 'NO', 'NONE')),
       decode(bitand(l.flags, 57344), 8192, 'LOW', 16384, 'MEDIUM', 32768,
              'HIGH',
              decode(bitand(l.property, 2048), 2048, 'NO', 'NONE')),
       decode(bitand(l.flags, 458752), 65536, 'LOB', 131072, 'OBJECT',
              327680, 'LOB VALIDATE', 393216, 'OBJECT VALIDATE',
              decode(bitand(l.property, 2048), 2048, 'NO', 'NONE')),
       decode(bitand(l.property, 2), 2, 'YES', 'NO'),
       decode(c.type#, 113, 'NOT APPLICABLE ',
              decode(bitand(l.property, 512), 512,
                     'ENDIAN SPECIFIC', 'ENDIAN NEUTRAL ')),
       decode(bitand(ta.property, 32), 32, 'YES', 'NO'),
       decode(bitand(l.property, 2048), 2048, 'YES', 'NO'),
       decode(bitand(l.property, 4096), 4096, 'NO',
              decode(bitand(ta.property, 32), 32, 'N/A', 'YES')),
       decode (bitand(l.property, 2048),
               2048,
               decode(bitand(ta.property, 17179869184), 17179869184,
                      decode(ds.lobret_stg, to_number(NULL), 'DEFAULT',
                                            0, 'NONE', 1, 'AUTO',
                                            2, 'MIN', 3, 'MAX',
                                            4, 'DEFAULT', 'INVALID'),
                      decode(s.lists, 0, 'NONE', 1, 'AUTO',
                                      2, 'MIN', 3, 'MAX',
                                      4, 'DEFAULT', 'INVALID')),
               decode(bitand(l.flags, 32), 32, 'YES', 'NO')),
       decode (bitand(l.property, 2048),
               2048,
               decode(bitand(ta.property, 17179869184), 17179869184,
                      decode(ds.lobret_stg, 2, ds.mintim_stg, to_number(NULL)),
                      decode(s.lists, 2, s.groups, to_number(NULL))))
from sys.obj$ o, sys.col$ c, sys.attrcol$ ac, sys.tab$ ta, sys.lob$ l,
     sys.obj$ lo, sys.obj$ io, sys.user$ u, sys.ts$ ts, sys.ts$ ts1,
     sys.seg$ s, sys.deferred_stg$ ds
where o.owner# = u.user#
  and bitand(o.flags, 128) = 0
  and o.obj# = c.obj#
  and c.obj# = l.obj#
  and c.intcol# = l.intcol#
  and l.lobj# = lo.obj#
  and l.ind# = io.obj#
  and l.ts# = ts.ts#(+)
  and u.tempts# = ts1.ts#
  and c.obj# = ac.obj#(+)
  and c.intcol# = ac.intcol#(+)
  and bitand(c.property,32768) != 32768           /* not unused column */
  and (o.owner# = userenv('SCHEMAID')
       or o.obj# in
            (select oa.obj#
             from sys.objauth$ oa
             where grantee# in ( select kzsrorol
                                 from x$kzsro
                               )
            )
       or /* user has System Privileges */
       ora_check_sys_privilege ( o.owner#, o.type#) = 1
      )
  and o.obj# = ta.obj#
  and bitand(ta.property, 32) != 32    /* not partitioned table */
  and l.file# = s.file#(+)
  and l.block# = s.block#(+)
  and l.ts# = s.ts#(+)
  and l.lobj# = ds.obj#(+)
union all
select u.name, o.name,
       decode(bitand(c.property, 1), 1, ac.name, c.name),
       lo.name,
       NVL(ts1.name,
        (select ts2.name
        from    ts$ ts2, partobj$ po
        where   o.obj# = po.obj# and po.defts# = ts2.ts#)),
       io.name,
       plob.defchunk * NVL(ts1.blocksize, NVL((
        select ts2.blocksize
        from   sys.ts$ ts2, sys.lobfrag$ lf
        where  l.lobj# = lf.parentobj# and
               lf.ts# = ts2.ts# and rownum < 2),
        (select ts2.blocksize
        from   sys.ts$ ts2, sys.lobcomppart$ lcp, sys.lobfrag$ lf
        where  l.lobj# = lcp.lobj# and lcp.partobj# = lf.parentobj# and
               lf.ts# = ts2.ts# and rownum < 2))),
       decode(bitand(plob.defflags, 32), 0, plob.defpctver$, to_number(NULL)),
       decode(bitand(plob.defflags, 32), 32,
              decode(bitand(plob.defpro, 2048), 2048, to_number(NULL),
                     l.retention), to_number(NULL)),
       decode(l.freepools, 0, to_number(NULL), 65534, to_number(NULL),
              65535, to_number(NULL), l.freepools),
       decode(bitand(plob.defflags, 795), 1, 'NO', 2, 'NO', 8, 'CACHEREADS',
                                         16, 'CACHEREADS', 256, 'YES',
                                         512, 'YES', 'YES'),
       decode(bitand(plob.defflags, 790), 0,'NONE', 4,'YES', 2,'NO',
                                        16,'NO', 256, 'NO', 512, 'YES',
                                        'UNKNOWN'),
       decode(bitand(plob.defflags, 4096), 4096, 'YES',
              decode(bitand(plob.defpro, 2048), 2048, 'NO', 'NONE')),
       decode(bitand(plob.defflags, 57344), 8192, 'LOW', 16384, 'MEDIUM',
              32768, 'HIGH',
              decode(bitand(plob.defpro, 2048), 2048, 'NO', 'NONE')),
       decode(bitand(plob.defflags, 458752), 65536, 'LOB', 131072, 'OBJECT',
              327680, 'LOB VALIDATE', 393216, 'OBJECT VALIDATE',
              decode(bitand(plob.defpro, 2048), 2048, 'NO', 'NONE')),
       decode(bitand(plob.defpro, 2), 2, 'YES', 'NO'),
       decode(c.type#, 113, 'NOT APPLICABLE ',
              decode(bitand(l.property, 512), 512,
                     'ENDIAN SPECIFIC', 'ENDIAN NEUTRAL ')),
       decode(bitand(ta.property, 32), 32, 'YES', 'NO'),
       decode(bitand(plob.defpro, 2048), 2048, 'YES', 'NO'),
       decode(bitand(l.property, 4096), 4096, 'NO', 'YES'),
       decode (bitand(plob.defpro, 2048), 2048,
               decode(bitand(ta.property, 17179869184), 17179869184,
                      decode(ds.lobret_stg, to_number(NULL), 'DEFAULT',
                                            0, 'NONE', 1, 'AUTO',
                                            2, 'MIN', 3, 'MAX',
                                            4, 'DEFAULT', 'INVALID'),
                      decode(s.lists, to_number(NULL), 'DEFAULT',
                                      0, 'NONE', 1, 'AUTO',
                                      2, 'MIN', 3, 'MAX',
                                      4, 'DEFAULT', 'INVALID')),
               decode(bitand(plob.defflags, 32), 32, 'YES', 'NO')),
       decode (bitand(plob.defpro, 2048),
               2048, decode(bitand(ta.property, 17179869184), 17179869184,
                            decode(ds.lobret_stg, 2, plob.defmintime,
                                   to_number(NULL)),
                            decode(s.lists, 2, plob.defmintime, to_number(NULL))
                           ))
from sys.obj$ o, sys.col$ c, sys.attrcol$ ac, sys.partlob$ plob,
     sys.lob$ l, sys.obj$ lo, sys.obj$ io, sys.ts$ ts1, sys.tab$ ta,
     sys.user$ u, sys.seg$ s, sys.deferred_stg$ ds
where o.owner# = u.user#
  and o.obj# = c.obj#
  and c.obj# = l.obj#
  and c.intcol# = l.intcol#
  and l.lobj# = lo.obj#
  and l.ind# = io.obj#
  and l.lobj# = plob.lobj#
  and plob.defts# = ts1.ts# (+)
  and c.obj# = ac.obj#(+)
  and c.intcol# = ac.intcol#(+)
  and bitand(c.property,32768) != 32768           /* not unused column */
  and (o.owner# = userenv('SCHEMAID')
       or o.obj# in
            (select oa.obj#
             from sys.objauth$ oa
             where grantee# in ( select kzsrorol
                                 from x$kzsro
                               )
            )
       or /* user has System Privileges */
       ora_check_sys_privilege ( o.owner#, o.type#) = 1
      )
  and o.obj# = ta.obj#
  and bitand(ta.property, 32) = 32         /* partitioned table */
  and l.file# = s.file#(+)
  and l.block# = s.block#(+)
  and l.ts# = s.ts#(+)
  and l.lobj# = ds.obj#(+)
/

