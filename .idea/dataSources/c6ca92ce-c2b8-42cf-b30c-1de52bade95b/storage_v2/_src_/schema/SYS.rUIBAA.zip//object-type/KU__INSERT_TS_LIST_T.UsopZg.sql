CREATE type ku$_insert_ts_list_t as table of ku$_insert_ts_t
/

