CREATE TYPE tts_info_tab_t IS TABLE OF tts_info_t;
/

