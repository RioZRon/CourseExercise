CREATE type ku$_tab_part_list_t as table of ku$_tab_part_t
/

