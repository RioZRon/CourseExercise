CREATE TYPE scheduler_filewatcher_req_list AS
  TABLE OF scheduler_filewatcher_request
/

