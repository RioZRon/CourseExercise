CREATE type ku$_cube_fact_list_t
 as table of ku$_cube_fact_t
/

