CREATE type ku$_part_col_list_t as table of ku$_part_col_t
/

