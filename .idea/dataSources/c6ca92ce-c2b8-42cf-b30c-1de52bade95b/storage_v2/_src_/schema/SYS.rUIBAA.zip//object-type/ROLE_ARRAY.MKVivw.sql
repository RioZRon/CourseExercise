CREATE type     role_array as varray(150) of number;
/

