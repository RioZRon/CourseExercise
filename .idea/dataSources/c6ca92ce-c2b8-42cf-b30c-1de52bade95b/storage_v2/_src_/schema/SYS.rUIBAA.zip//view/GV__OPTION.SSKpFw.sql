CREATE VIEW GV_$OPTION AS
  select "INST_ID","PARAMETER","VALUE","CON_ID" from gv$option
/

