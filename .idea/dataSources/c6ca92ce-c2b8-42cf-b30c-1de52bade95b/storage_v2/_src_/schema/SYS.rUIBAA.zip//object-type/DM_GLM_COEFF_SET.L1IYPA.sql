CREATE type dm_glm_coeff_set
                                       as table of dm_glm_coeff
/

