CREATE TYPE     re$column_value_list
AS VARRAY(1024) OF sys.re$column_value
/

