CREATE TYPE     ku$_DumpFileSet1010 AS TABLE OF sys.ku$_DumpFile1010
/

