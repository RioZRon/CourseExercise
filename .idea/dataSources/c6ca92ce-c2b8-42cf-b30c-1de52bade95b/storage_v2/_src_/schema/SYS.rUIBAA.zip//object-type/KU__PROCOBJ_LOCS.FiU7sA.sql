CREATE TYPE     ku$_procobj_locs AS TABLE OF sys.ku$_procobj_loc
/

