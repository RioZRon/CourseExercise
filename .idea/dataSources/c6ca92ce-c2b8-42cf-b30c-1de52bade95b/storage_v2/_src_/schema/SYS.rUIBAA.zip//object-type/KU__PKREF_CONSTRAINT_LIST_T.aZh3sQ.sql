CREATE type ku$_pkref_constraint_list_t
 as table of ku$_pkref_constraint_t;
/

