CREATE TYPE     ExplainMVArrayType AS VARRAY(200) OF SYS.ExplainMVMessage
/

