CREATE type aq$_jms_array_msgids
                                                                      
as varray(2147483647) of raw(16);
/

