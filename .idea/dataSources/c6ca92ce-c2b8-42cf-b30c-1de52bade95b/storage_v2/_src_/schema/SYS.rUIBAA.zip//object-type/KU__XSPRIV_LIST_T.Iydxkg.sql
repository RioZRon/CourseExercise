CREATE type ku$_xspriv_list_t as table of ku$_xspriv_t;
/

