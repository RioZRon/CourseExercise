CREATE type dm_svd_matrix_set
                                       as table of dm_svd_matrix
/

