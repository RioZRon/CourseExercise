CREATE type ku$_cube_dim_list_t
 as table of ku$_cube_dim_t
/

