CREATE VIEW V_$NLS_PARAMETERS AS
  select "PARAMETER","VALUE","CON_ID" from v$nls_parameters
/

