CREATE type chnf$_qdesc_array as VARRAY(1073741824) of chnf$_qdesc
/

