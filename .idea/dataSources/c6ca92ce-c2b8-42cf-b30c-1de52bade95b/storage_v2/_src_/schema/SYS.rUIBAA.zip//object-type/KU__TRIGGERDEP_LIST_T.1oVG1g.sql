CREATE type ku$_triggerdep_list_t
 as table of ku$_triggerdep_t
/

