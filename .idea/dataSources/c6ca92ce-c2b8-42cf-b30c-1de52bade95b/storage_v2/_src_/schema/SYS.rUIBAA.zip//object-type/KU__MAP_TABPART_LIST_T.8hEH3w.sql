CREATE type ku$_map_tabpart_list_t as table of ku$_map_table_t;
/

