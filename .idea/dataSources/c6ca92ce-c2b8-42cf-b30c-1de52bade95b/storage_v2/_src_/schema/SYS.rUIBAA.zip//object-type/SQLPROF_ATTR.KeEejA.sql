CREATE TYPE     sqlprof_attr
                                                                      
AS VARRAY(2000) of VARCHAR2(500)
/

