CREATE type ku$_xsnstmpl_attr_list_t as table of ku$_xsnstmpl_attr_t;
/

