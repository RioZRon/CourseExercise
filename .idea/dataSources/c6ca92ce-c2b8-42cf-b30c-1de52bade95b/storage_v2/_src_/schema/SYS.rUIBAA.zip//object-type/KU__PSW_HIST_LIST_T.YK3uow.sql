CREATE type ku$_psw_hist_list_t as TABLE of ku$_psw_hist_item_t
/

