CREATE TYPE     kupc$_mdFilePieceList AS TABLE OF SYS.kupc$_mdFilePiece
/

