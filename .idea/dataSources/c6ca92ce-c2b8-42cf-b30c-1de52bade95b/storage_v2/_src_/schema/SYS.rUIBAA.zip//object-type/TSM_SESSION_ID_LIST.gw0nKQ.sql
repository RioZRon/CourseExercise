CREATE TYPE     tsm$session_id_list
                                                                      
AS VARRAY(4096) of sys.tsm$session_id
/

