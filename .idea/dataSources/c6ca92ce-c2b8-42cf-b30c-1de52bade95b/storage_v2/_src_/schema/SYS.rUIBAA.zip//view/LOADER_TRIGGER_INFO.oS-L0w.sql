CREATE VIEW LOADER_TRIGGER_INFO AS
  select u1.name, o1.name, u.name, o.name, t.enabled
   from sys.obj$ o, sys."_CURRENT_EDITION_OBJ" o1, sys.user$ u, sys.user$ u1,
        sys.trigger$ t
   where t.baseobject = o.obj#
   and o.owner# = u.user#
   and o1.owner# = u1.user#
   and t.obj# = o1.obj#
 and (o.owner# = userenv('schemaid')
       or o.obj# in
            (select oa.obj#
             from sys.objauth$ oa
             where grantee# in ( select kzsrorol
                                 from x$kzsro
                               )
            )
       or
          ora_check_SYS_privilege (o.owner#, o.type#) = 1
     )
/

