CREATE type ora_mining_varchar2_nt
                                       as table of varchar2(4000)
/

