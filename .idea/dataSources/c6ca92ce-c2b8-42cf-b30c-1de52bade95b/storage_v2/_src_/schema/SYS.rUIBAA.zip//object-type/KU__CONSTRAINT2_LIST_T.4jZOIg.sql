CREATE type ku$_constraint2_list_t as table of ku$_constraint2_t;
/

