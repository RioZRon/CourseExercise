CREATE type dm_model_signature
                                      
  as table of dm_model_signature_attribute
/

