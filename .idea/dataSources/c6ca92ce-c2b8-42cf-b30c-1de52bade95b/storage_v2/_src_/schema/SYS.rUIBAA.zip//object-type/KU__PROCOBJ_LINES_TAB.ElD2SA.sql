CREATE TYPE     ku$_procobj_lines_tab AS TABLE OF sys.ku$_procobj_lines
/

