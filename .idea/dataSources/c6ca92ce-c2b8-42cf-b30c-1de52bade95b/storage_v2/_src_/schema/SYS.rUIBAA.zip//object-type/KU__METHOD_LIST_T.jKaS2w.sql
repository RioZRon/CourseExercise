CREATE type ku$_method_list_t
   as table of ku$_method_t
/

