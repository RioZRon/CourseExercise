CREATE type ku$_constraint_col_list_t
 as TABLE of ku$_constraint_col_t;
/

