CREATE TYPE     ku$_dumpfile_info AS TABLE OF sys.ku$_dumpfile_item
/

