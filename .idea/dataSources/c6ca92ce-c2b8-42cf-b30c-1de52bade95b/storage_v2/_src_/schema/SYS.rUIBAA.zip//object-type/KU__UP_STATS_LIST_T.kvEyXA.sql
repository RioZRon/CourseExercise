CREATE type ku$_up_stats_list_t
  as table of ku$_up_stats_t
/

