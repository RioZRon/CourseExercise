CREATE TYPE     ku$_ErrorLines AS TABLE OF sys.ku$_ErrorLine
/

