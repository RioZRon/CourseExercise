CREATE type ku$_hier_hier_attr_list_t
  as table of ku$_hier_hier_attr_t
/

