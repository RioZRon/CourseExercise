CREATE TYPE     aq$_subscriber_t AS TABLE OF aq$_subscriber;
/

