CREATE type ku$_10_1_col_stats_list_t
  as table of ku$_10_1_col_stats_t
/

