CREATE type DS_VARRAY_4_CLOB                                       
as   varray(2000000000) of varchar2(4000 char)
/

