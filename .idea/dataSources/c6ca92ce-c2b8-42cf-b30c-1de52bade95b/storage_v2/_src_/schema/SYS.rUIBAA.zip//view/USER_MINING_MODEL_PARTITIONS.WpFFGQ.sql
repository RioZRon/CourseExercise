CREATE VIEW USER_MINING_MODEL_PARTITIONS AS
  select model_name, partition_name, position, column_name, hiboundval from (
select o.name model_name,
       o.subname partition_name,
       mp.pos#  position,
       mpc.name column_name,
       hiboundval
from modelpart$ mp, obj$ o, modelpartcol$ mpc
where mp.obj#=o.obj#
  and o.owner#=userenv('SCHEMAID')
  and mp.mod#=mpc.obj#
  and mp.pos#=mpc.pos#
  and mp.pos# is not null)
/

