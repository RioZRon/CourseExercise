CREATE TYPE dbms_aw$_dimension_sources_t
   AS TABLE OF dbms_aw$_dimension_source_t
/

