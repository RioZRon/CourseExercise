CREATE type ku$_piot_part_list_t as table of ku$_piot_part_t
/

