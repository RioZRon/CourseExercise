CREATE TYPE     role_name_list IS VARRAY(10) OF varchar(128);
/

