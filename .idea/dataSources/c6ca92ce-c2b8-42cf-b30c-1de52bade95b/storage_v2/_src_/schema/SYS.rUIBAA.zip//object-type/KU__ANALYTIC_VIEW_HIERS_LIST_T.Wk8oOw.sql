CREATE type ku$_analytic_view_hiers_list_t
  as table of ku$_analytic_view_hiers_t
/

