CREATE type ku$_tab_subpart_list_t as table of ku$_tab_subpart_t
/

