CREATE TYPE     ku$_WorkerStatusList1210 AS TABLE OF sys.ku$_WorkerStatus1210
/

