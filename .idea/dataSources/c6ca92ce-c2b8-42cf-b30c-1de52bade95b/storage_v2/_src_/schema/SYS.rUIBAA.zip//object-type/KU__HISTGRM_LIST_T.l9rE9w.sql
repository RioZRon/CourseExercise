CREATE type ku$_histgrm_list_t
  as table of ku$_histgrm_t
/

