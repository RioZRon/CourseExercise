CREATE type chnf$_rdesc_array as VARRAY(1073741824) of chnf$_rdesc
/

