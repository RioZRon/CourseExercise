CREATE TYPE     ku$_LogEntry1010 AS TABLE OF sys.ku$_LogLine1010
/

