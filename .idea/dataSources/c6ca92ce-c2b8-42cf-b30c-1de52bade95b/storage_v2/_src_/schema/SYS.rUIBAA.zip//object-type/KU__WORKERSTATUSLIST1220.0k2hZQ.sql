CREATE TYPE     ku$_WorkerStatusList1220 AS TABLE OF sys.ku$_WorkerStatus1220
/

