CREATE TYPE     aq$_subscribers
                                                                      
AS VARRAY(1024) OF sys.aq$_agent
/

