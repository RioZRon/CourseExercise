CREATE TYPE     streams$_anydata_array
 AS VARRAY(2147483647) of sys.anydata
/

