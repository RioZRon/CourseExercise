CREATE type ku$_radm_mc_list_t as table of ku$_radm_mc_t
/

