CREATE VIEW USER_DB_LINKS AS
  select l.name, l.userid, l.password, l.host, l.ctime,
       decode(bitand(l.flag, 8), 8, 'YES', 'NO')
from sys.link$ l
where l.owner# = userenv('SCHEMAID')
/

