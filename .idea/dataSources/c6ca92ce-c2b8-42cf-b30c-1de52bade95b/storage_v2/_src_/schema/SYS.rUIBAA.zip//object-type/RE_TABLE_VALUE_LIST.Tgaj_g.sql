CREATE TYPE     re$table_value_list
AS VARRAY(1024) OF sys.re$table_value
/

