CREATE type dm_rules
                                       as table of dm_rule
/

