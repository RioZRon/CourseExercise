CREATE type ku$_opbinding_list_t as TABLE of ku$_opbinding_t
/

