CREATE type dm_predicates
                                       as table of dm_predicate
/

