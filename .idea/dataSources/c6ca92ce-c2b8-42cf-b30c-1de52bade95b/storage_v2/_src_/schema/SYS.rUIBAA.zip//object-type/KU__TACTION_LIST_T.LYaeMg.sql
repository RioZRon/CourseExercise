CREATE TYPE     ku$_taction_list_t IS TABLE OF sys.ku$_taction_t
/

