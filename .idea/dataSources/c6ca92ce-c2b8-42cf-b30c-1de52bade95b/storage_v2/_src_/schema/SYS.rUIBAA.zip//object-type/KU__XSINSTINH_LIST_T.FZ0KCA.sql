CREATE type ku$_xsinstinh_list_t as table of ku$_xsinst_inh_t;
/

