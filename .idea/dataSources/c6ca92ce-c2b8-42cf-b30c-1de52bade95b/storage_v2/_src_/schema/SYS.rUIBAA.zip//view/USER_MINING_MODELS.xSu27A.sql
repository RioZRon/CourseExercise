CREATE VIEW USER_MINING_MODELS AS
  select o.name,
       cast(decode(func, /* Mining Function */
              1, 'CLASSIFICATION',
              2, 'REGRESSION',
              3, 'CLUSTERING',
              4, 'FEATURE_EXTRACTION',
              5, 'ASSOCIATION_RULES',
              6, 'ATTRIBUTE_IMPORTANCE',
                 'UNDEFINED') as varchar2(30)),
       cast(decode(alg, /* Mining Algorithm */
              1, 'NAIVE_BAYES',
              2, 'ADAPTIVE_BAYES_NETWORK',
              3, 'DECISION_TREE',
              4, 'SUPPORT_VECTOR_MACHINES',
              5, 'KMEANS',
              6, 'O_CLUSTER',
              7, 'NONNEGATIVE_MATRIX_FACTOR',
              8, 'GENERALIZED_LINEAR_MODEL',
              9, 'APRIORI_ASSOCIATION_RULES',
             10, 'MINIMUM_DESCRIPTION_LENGTH',
             11, 'SINGULAR_VALUE_DECOMP',
             12, 'EXPECTATION_MAXIMIZATION',
             13, 'R_EXTENSIBLE',
             14, 'EXPLICIT_SEMANTIC_ANALYS',
                 'UNDEFINED') as varchar2(30)),
       o.ctime, bdur, msize,
       decode(bitand(m.properties,1),1,'YES','NO'), c.comment$
from sys.model$ m, sys.obj$ o, sys.com$ c
where o.obj#=m.obj#
  and o.obj#=c.obj#(+)
  and o.type#=82
  and o.owner#=userenv('SCHEMAID')
/

