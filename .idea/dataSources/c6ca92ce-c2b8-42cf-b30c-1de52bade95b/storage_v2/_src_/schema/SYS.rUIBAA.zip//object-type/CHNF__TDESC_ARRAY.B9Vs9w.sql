CREATE type chnf$_tdesc_array as VARRAY(1073741824) of chnf$_tdesc
/

