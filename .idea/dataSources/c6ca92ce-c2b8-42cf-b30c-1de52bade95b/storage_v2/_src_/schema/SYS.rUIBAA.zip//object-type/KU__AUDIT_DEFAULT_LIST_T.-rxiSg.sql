CREATE TYPE     ku$_audit_default_list_t IS TABLE OF sys.ku$_auddef_t
/

