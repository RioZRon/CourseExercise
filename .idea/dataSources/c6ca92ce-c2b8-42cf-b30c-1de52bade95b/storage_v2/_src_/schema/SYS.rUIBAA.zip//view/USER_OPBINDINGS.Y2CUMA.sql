CREATE VIEW USER_OPBINDINGS AS
  select  c.name, b.name, a.bind#, a.functionname, a.returnschema,
        a.returntype, a.impschema, a.imptype,
        decode(bitand(a.property,31), 1, 'WITH INDEX CONTEXT',
               3 , 'COMPUTE ANCILLARY DATA', 4 , 'ANCILLARY TO',
               16 , 'WITH COLUMN CONTEXT' ,
               17,  'WITH INDEX, COLUMN CONTEXT',
               19, 'COMPUTE ANCILLARY DATA, WITH COLUMN CONTEXT')
  from  sys.opbinding$ a, sys.obj$ b, sys.user$ c
  where a.obj# = b.obj# and b.owner# = c.user#
  and b.owner# = userenv ('SCHEMAID')
/

