CREATE type ku$_strmcol_list_t as table of ku$_strmcol_t
/

