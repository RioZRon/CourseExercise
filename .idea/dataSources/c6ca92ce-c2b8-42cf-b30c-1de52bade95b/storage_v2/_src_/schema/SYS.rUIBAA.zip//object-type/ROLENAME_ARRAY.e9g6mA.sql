CREATE type     rolename_array as varray(150) of varchar2(128);
/

