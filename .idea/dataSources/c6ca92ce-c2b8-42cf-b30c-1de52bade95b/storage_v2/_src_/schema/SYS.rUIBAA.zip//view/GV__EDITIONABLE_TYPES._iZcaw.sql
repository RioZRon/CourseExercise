CREATE VIEW GV_$EDITIONABLE_TYPES AS
  select "INST_ID","EDITIONABLE_TYPE","TYPE#","CON_ID" from gv$editionable_types
/

