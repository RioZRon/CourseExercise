CREATE type dm_children
                                       as table of dm_child
/

