CREATE type ku$_hier_lvl_list_t
  as table of ku$_hier_lvl_t
/

