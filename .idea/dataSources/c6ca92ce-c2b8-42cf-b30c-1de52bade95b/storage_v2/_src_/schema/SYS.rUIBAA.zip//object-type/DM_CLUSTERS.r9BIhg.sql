CREATE type dm_clusters
                                       as table of dm_cluster
/

