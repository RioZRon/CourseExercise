CREATE type XMLSequenceType                                       
as varray(2147483647) of XMLType;
/

