CREATE VIEW USER_CLUSTERING_KEYS AS
  select owner, table_name, detail_owner, detail_name, detail_column,
       position, groupid
from DBA_CLUSTERING_KEYS
WHERE owner = SYS_CONTEXT('USERENV','CURRENT_USER')
/

