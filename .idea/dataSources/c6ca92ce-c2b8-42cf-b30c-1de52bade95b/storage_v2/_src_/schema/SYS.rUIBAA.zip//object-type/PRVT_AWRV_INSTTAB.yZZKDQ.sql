CREATE TYPE prvt_awrv_instTab AS TABLE OF prvt_awrv_inst;
/

