CREATE type prvt_awrv_varchar64Tab as table of varchar2(64);
/

