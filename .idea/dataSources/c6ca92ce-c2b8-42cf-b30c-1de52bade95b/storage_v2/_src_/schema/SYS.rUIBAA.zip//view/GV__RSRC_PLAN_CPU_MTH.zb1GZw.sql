CREATE VIEW GV_$RSRC_PLAN_CPU_MTH AS
  select "INST_ID","NAME","CON_ID" from gv$rsrc_plan_cpu_mth
/

