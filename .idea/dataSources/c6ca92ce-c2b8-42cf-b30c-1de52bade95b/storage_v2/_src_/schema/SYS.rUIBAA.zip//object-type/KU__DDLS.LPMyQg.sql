CREATE TYPE     ku$_ddls IS TABLE OF sys.ku$_ddl;
/

