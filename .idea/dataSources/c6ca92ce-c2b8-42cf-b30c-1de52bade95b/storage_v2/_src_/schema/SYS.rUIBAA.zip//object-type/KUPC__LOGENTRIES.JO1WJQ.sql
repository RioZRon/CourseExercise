CREATE TYPE kupc$_LogEntries AS VARRAY(10) OF ku$_LogEntry
/

