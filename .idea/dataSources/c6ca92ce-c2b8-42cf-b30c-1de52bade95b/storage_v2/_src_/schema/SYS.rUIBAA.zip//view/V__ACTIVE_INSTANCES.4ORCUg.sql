CREATE VIEW V_$ACTIVE_INSTANCES AS
  select "INST_NUMBER","INST_NAME","CON_ID" from v$active_instances
/

