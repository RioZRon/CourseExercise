CREATE type ku$_ptab_stats_list_t
  as table of ku$_tab_ptab_stats_t
/

