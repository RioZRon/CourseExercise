CREATE TYPE lcr$_ddl_record                                       
AS OPAQUE VARYING (*)
USING LIBRARY lcr_ddl_lib
(
   -- Constructor
   STATIC FUNCTION construct(
     source_database_name       in varchar2,
     command_type               in varchar2,
     object_owner               in varchar2,
     object_name                in varchar2,
     object_type                in varchar2,
     ddl_text                   in clob,
     logon_user                 in varchar2,
     current_schema             in varchar2,
     base_table_owner           in varchar2,
     base_table_name            in varchar2,
     tag                        in raw               DEFAULT NULL,
     transaction_id             in varchar2          DEFAULT NULL,
     scn                        in number            DEFAULT NULL,
     position                   in raw               DEFAULT NULL,
     edition_name               in varchar2          DEFAULT NULL,
     current_user               in varchar2          DEFAULT NULL,
     root_name                  in varchar2          DEFAULT NULL
   )
   RETURN lcr$_ddl_record,

   MAP MEMBER FUNCTION map_lcr RETURN NUMBER,

   ---------------## Accessors for lcr$_ddl_record.source_database_name
   -- This function returns the source database name. If there is
   -- no source database name, NULL is returned.
   MEMBER FUNCTION get_source_database_name RETURN varchar2,

   -- Sets the name of the source database
   MEMBER PROCEDURE set_source_database_name
   (self in out nocopy lcr$_ddl_record,
    source_database_name IN varchar2),

   --------------## Accessors for lcr$_ddl_record.command_type
   -- This FUNCTION returns command type.
   MEMBER FUNCTION get_command_type RETURN varchar2,

   -- This procedure sets command type. If an input command_type
   -- does not make sense, an exception will be raised. For example,
   -- changing INSERT to GRANT.
   MEMBER PROCEDURE set_command_type (self in out nocopy lcr$_ddl_record,
                                      command_type IN varchar2),
   --------------## Accessors for lcr$_ddl_record.object_owner
   -- This FUNCTION returns the owner of the object.
   MEMBER FUNCTION get_object_owner RETURN varchar2,

   -- This procedure sets the owner of the object.
   MEMBER PROCEDURE set_object_owner
    (self in out nocopy lcr$_ddl_record, object_owner IN VARCHAR2),

   --------------## Accessors for lcr$_ddl_record.object_name
   -- This FUNCTION returns the name of the object.
   MEMBER FUNCTION get_object_name RETURN varchar2,

   -- This procedure sets the name of the object.
   MEMBER PROCEDURE set_object_name
    (self in out nocopy lcr$_ddl_record, object_name IN VARCHAR2),

   --------------## Accessors for lcr$_ddl_record.transaction_id
   -- This function returns the transaction ID of the LCR.
   MEMBER FUNCTION get_transaction_id       RETURN VARCHAR2,

   -- This function returns the system change NUMBER (SCN) of the LCR.
   MEMBER FUNCTION get_scn RETURN NUMBER,

   --------------## Accessors for lcr$_ddl_record.object_type
   -- This FUNCTION returns the type of the object.
   MEMBER FUNCTION get_object_type RETURN varchar2,

   -- This procedure sets the type of the object.
   MEMBER PROCEDURE set_object_type
    (self in out nocopy lcr$_ddl_record, object_type IN VARCHAR2),

   --------------## Accessors for lcr$_ddl_record.logon_user
   -- This FUNCTION returns the logon user name
   MEMBER FUNCTION get_logon_user RETURN varchar2,

   -- This procedure sets the logon user name
   MEMBER PROCEDURE set_logon_user
    (self in out nocopy lcr$_ddl_record, logon_user IN VARCHAR2),

   --------------## Accessors for lcr$_ddl_record.current_schema
   -- This FUNCTION returns the current schema
   MEMBER FUNCTION get_current_schema RETURN varchar2,

   -- This procedure sets the current schema
   MEMBER PROCEDURE set_current_schema
    (self in out nocopy lcr$_ddl_record, current_schema IN VARCHAR2),

   --------------## Accessors for lcr$_ddl_record.base_table_owner
   -- This FUNCTION returns the base owner name
   MEMBER FUNCTION get_base_table_owner RETURN varchar2,

   -- This procedure sets the base owner name
   MEMBER PROCEDURE set_base_table_owner
    (self in out nocopy lcr$_ddl_record, base_table_owner IN VARCHAR2),

   --------------## Accessors for lcr$_ddl_record.base_table_name
   -- This FUNCTION returns the base table name
   MEMBER FUNCTION get_base_table_name RETURN varchar2,

   -- This procedure sets the base table name
   MEMBER PROCEDURE set_base_table_name
    (self in out nocopy lcr$_ddl_record, base_table_name IN VARCHAR2),

   --------------## Accessors for lcr$_ddl_record.ddl_text
   -- This FUNCTION returns ddl text
   MEMBER PROCEDURE get_ddl_text
    (self in lcr$_ddl_record, ddl_text IN OUT NOCOPY CLOB),

   -- This procedure sets ddl text
   MEMBER PROCEDURE set_ddl_text
    (self in out nocopy lcr$_ddl_record, ddl_text IN CLOB),

   --------------------------------------------## Methods for tag
   -- This function sets the tag for the LCR
   MEMBER PROCEDURE set_tag(self in out nocopy lcr$_ddl_record,
       tag    IN RAW),

   -- This function gets the tag for the LCR
   MEMBER FUNCTION get_tag      RETURN RAW,

   -- This function returns 'Y' or 'N' depending on whether or not
   -- tag for the LCR is NULL
   MEMBER FUNCTION is_null_tag  RETURN VARCHAR2,

   -- This procedure constructs and applys the statement from the ddl lcr
   MEMBER procedure execute(self in lcr$_ddl_record),

   -- This function returns the system change NUMBER (SCN) of the commit lcr
   -- for the transaction to which this lcr belongs.
   -- FOR INTERNAL USE ONLY
   MEMBER FUNCTION get_commit_scn RETURN NUMBER,

   -- This function returns the source time of the commit lcr
   -- for the transaction to which this lcr belongs to.
   MEMBER FUNCTION get_commit_time RETURN DATE,

   --------------## Accessors for the the optional attributes
   -- This FUNCTION returns the value for the corresponding optional attribute.
   -- If the value is NULL, then a sys.AnyData instance with a NULL
   -- value inside is returned. If no value for such an attribute exists,
   -- NULL is returned.
   MEMBER FUNCTION get_extra_attribute(
        attribute_name         IN VARCHAR2) RETURN Sys.AnyData,

   -- Overwrites the attribute value for the specified attribute
   -- If value is NULL, the existing attribute will be removed.
   MEMBER procedure set_extra_attribute(self in out nocopy lcr$_ddl_record,
        attribute_name         IN VARCHAR2,
        attribute_value        IN Sys.AnyData),

   -- Returns the minimum compatible setting when such LCR is supported
   -- by Streams.
   MEMBER FUNCTION get_compatible RETURN NUMBER,

   -- Returns the creation/redo generation time of the lcr
   MEMBER FUNCTION get_source_time RETURN DATE,

   -- Returns the thread number where the redo for the lcr was generated
   MEMBER FUNCTION get_thread_number RETURN NUMBER,

   -- Returns the position
   MEMBER FUNCTION get_position RETURN RAW,

   -- Return the LCR SCN from an XStream Out position.
   STATIC FUNCTION get_scn_from_position(position IN RAW) RETURN NUMBER,

   -- Return the commit SCN from an XStream Out position.
   STATIC FUNCTION get_commit_scn_from_position(position IN RAW) RETURN NUMBER,

   -- Returns the edition_name
   MEMBER FUNCTION get_edition_name RETURN varchar2,

   -- Sets the edition_name
   MEMBER PROCEDURE set_edition_name
    (self in out nocopy lcr$_ddl_record, edition_name IN VARCHAR2),

   --------------## Accessors for lcr$_ddl_record.current_user
   -- This FUNCTION returns the current user
   MEMBER FUNCTION get_current_user RETURN varchar2,

   -- This procedure sets the current_user
   MEMBER PROCEDURE set_current_user
    (self in out nocopy lcr$_ddl_record, current_user IN VARCHAR2),

   -- This procedure sets the source root name
   MEMBER PROCEDURE set_root_name
    (self in out nocopy lcr$_ddl_record, root_name IN VARCHAR2),
   -- This FUNCTION returns the source root name
   MEMBER FUNCTION get_root_name RETURN varchar2

)
/

