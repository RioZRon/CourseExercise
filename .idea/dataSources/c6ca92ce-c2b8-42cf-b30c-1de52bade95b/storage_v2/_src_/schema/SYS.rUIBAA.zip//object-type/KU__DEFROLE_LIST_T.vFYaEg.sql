CREATE type ku$_defrole_list_t as TABLE of ku$_defrole_item_t
/

