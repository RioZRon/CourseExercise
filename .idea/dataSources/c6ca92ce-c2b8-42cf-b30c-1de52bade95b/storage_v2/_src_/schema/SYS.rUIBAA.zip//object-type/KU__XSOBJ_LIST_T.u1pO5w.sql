CREATE type ku$_xsobj_list_t as table of ku$_xsobj_t;
/

