CREATE VIEW USER_XTERNAL_TAB_SUBPARTITIONS AS
  select po.name, po.subname, so.subname, 'SYS', xt.default_dir,
       decode(xt.par_type, 1, 'BLOB', 2, 'CLOB',       'UNKNOWN'),
       case when xt.par_type = 2 then xt.param_clob else NULL end
from   sys.external_tab$ xt, sys.obj$ so, sys.obj$ po, sys.tabcompart$ tcp,
       sys.tabsubpart$ tsp, sys.tab$ t
where so.obj# = xt.obj# and
      so.obj# = tsp.obj# and
      po.obj# = tsp.pobj# and
      tcp.obj# = tsp.pobj# and
      tcp.bo# = t.obj# and
      po.owner# = userenv('SCHEMAID') and
      so.owner# = userenv('SCHEMAID') and
      po.namespace = 1 and
      po.remoteowner IS NULL and
      po.linkname IS NULL and
      so.namespace = 1 and
      so.remoteowner IS NULL and
      so.linkname IS NULL
/

