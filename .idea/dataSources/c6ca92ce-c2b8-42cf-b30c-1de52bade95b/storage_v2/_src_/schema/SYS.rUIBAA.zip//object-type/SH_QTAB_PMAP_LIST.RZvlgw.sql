CREATE TYPE     sh$qtab_pmap_list AS VARRAY(1000000) OF sys.sh$qtab_pmap;
/

