CREATE VIEW ALL_MINING_MODEL_VIEWS AS
  select u.name,
       o1.name,
       o2.name,
       cast(decode(typ#,
               101 , 'Clustering Description',
	       102 , 'Clustering Attribute Statistics',
	       103 , 'Clustering Histograms',
	       104 , 'Clustering Rules',
	       105 , 'Model Build Alerts',
	       106 , 'Computed Settings',
	       107 , 'Global Name-Value Pairs',
	       108 , 'Classification Targets',
	       109 , 'Scoring Cost Matrix',
	       110 , 'Decision Tree Build Cost Matrix',
	       111 , 'Text Features',
	       112 , 'Normalization and Missing Value Handling',
	       113 , 'Automatic Data Preparation Binning',
	       114 , 'Decision Tree Hierarchy',
	       115 , 'Decision Tree Statistics',
	       116 , 'Decision Tree Nodes',
	       117 , 'Association Rules',
	       118 , 'Association Rule Itemsets',
	       119 , 'SVM Linear Coefficients',
	       120 , 'Expectation Maximization Components',
	       121 , 'Expectation Maximization Projections',
	       122 , 'GLM Regression Attribute Diagnostics',
	       123 , 'GLM Regression Row Diagnostics',
	       124 , 'GLM Classification Attribute Diagnostics',
	       125 , 'GLM Classification Row Diagnostics',
           126 , 'R-Glue Details',
           127 , 'Attribute Importance',
           128 , 'Naive Bayes Target Priors',
           129 , 'Naive Bayes Conditional Probabilities',
           130 , 'Explicit Semantic Analysis Features',
           131 , 'Explicit Semantic Analysis Matrix',
           132 , 'Singular Value Decomposition U Matrix',
           133 , 'Singular Value Decomposition S Matrix',
           134 , 'Singular Value Decomposition V Matrix',
           135 , 'k-Means Scoring Centroids',
           136 , 'Non-Negative Matrix Factorization H Matrix',
           137 , 'Non-Negative Matrix Factorization Inverse H Matrix',
           138 , 'Expectation Maximization Gaussian parameters',
           139 , 'Expectation Maximization Bernoulli parameters',
           140 , 'Unsupervised Attribute Importance',
           141 , 'Attribute Pair Kullback-Leibler Divergence',
           142 , 'Association Rule Itemsets for transactional data',
           143 , 'Association Rules for transactional data',
                 'UNDEFINED') as varchar2(128))
from sys.model$ m, sys.modeltab$ t, sys.obj$ o1, sys.obj$ o2, sys.user$ u
where m.obj#=o1.obj#
  and m.obj#=t.mod#
  and t.obj#=o2.obj#
  and o1.owner#=u.user#
  and t.typ# >= 100
  and (o1.owner#=userenv('SCHEMAID')
       or o1.obj# in
            (select oa.obj#
             from sys.objauth$ oa
             where oa.grantee# in ( select kzsrorol
                                         from x$kzsro
                                  )
            )
        or /* user has system privileges */
          ora_check_sys_privilege (o1.owner#, o1.type#) = 1
     )
/

