CREATE type ku$_xsaclparam_list_t as table of ku$_xsaclparam_t;
/

