CREATE type ku$_slog_list_t
  as table of ku$_slog_t
/

