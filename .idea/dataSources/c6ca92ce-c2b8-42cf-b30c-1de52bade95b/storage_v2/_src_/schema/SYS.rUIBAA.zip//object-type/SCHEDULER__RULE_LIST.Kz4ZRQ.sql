CREATE TYPE     scheduler$_rule_list IS
 TABLE OF sys.scheduler$_rule
/

