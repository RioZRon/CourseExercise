CREATE type dm_ranked_attributes
                                      
  as table of dm_ranked_attribute
/

