CREATE type aq$_jms_array_errors
                                                                      
as varray(2147483647) of aq$_jms_array_error_info;
/

