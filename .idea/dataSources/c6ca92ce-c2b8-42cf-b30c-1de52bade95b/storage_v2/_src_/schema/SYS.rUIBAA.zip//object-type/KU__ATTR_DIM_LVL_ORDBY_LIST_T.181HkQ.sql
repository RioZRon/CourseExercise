CREATE type ku$_attr_dim_lvl_ordby_list_t
  as table of ku$_attr_dim_lvl_ordby_t
/

