CREATE TYPE     ku$_multi_ddls IS TABLE OF sys.ku$_multi_ddl;
/

