CREATE type ku$_xsaggpriv_list_t as table of ku$_xsaggpriv_t;
/

