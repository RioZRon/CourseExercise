CREATE type ku$_xsrgrant_list_t as table of ku$_xsrole_grant_t;
/

