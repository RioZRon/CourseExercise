CREATE VIEW V_$SQLPA_METRIC AS
  select "METRIC_NAME","CON_ID" from v$sqlpa_metric
/

