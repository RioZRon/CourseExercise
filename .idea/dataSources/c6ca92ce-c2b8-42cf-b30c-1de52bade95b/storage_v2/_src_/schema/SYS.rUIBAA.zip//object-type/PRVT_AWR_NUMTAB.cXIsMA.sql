CREATE TYPE prvt_awr_numtab
AS TABLE OF NUMBER;
/

