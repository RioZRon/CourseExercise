CREATE TYPE     ku$_SubmitResults AS TABLE OF sys.ku$_SubmitResult
/

