CREATE TYPE     scheduler$_step_type_list IS
 TABLE OF sys.scheduler$_step_type
/

