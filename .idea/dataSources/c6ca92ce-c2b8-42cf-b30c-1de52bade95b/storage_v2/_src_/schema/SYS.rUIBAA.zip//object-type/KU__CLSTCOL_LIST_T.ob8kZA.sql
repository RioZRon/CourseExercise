CREATE type ku$_clstcol_list_t as table of ku$_clstcol_t
/

