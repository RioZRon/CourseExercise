CREATE VIEW ALL_SQL_TRANSLATION_PROFILES AS
  select u.name, o.name,
       case when (s.txlrowner is null and s.txlrname is null) then
         null
       else
         '"'||s.txlrowner||'"."'||s.txlrname||'"'
       end,
       decode(bitand(s.flags, 1), 1, 'TRUE', 0, 'FALSE'),
       decode(bitand(s.flags, 2), 2, 'TRUE', 0, 'FALSE'),
       decode(bitand(s.flags, 4), 4, 'TRUE', 0, 'FALSE'),
       decode(bitand(s.flags, 8), 8, 'TRUE', 0, 'FALSE'),
       decode(bitand(s.flags, 16), 16, 'TRUE', 0, 'FALSE'),
       decode(bitand(s.flags, 32), 32, 'TRUE', 0, 'FALSE')
  from sys.sqltxl$ s, sys."_CURRENT_EDITION_OBJ" o, sys.user$ u
 where s.obj# = o.obj# and
       o.owner# = u.user# and
       (
         o.owner# = userenv('SCHEMAID')
         or
         exists (select null from sys.objauth$ oa
                  where oa.obj# = o.obj#
                    and oa.grantee# in (select kzsrorol from x$kzsro)
                    and oa.privilege# in (0 /* ALTER */, 29 /* USE */))
         or
         exists (select null from v$enabledprivs
                 where priv_number in (
                                -335 /* CREATE ANY SQL TRANSLATION PROFILE */,
                                -336 /* ALTER ANY SQL TRANSLATION PROFILE  */,
                                -337 /* USE ANY SQL TRANSLATION PROFILE    */,
                                -338 /* DROP ANY SQL TRANSLATION PROFILE   */
                                      )
                )
       )
/

