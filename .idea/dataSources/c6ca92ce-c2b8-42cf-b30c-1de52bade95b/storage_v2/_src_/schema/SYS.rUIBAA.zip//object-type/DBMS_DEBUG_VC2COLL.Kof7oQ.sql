CREATE TYPE dbms_debug_vc2coll is table of varchar2(1000)
/

