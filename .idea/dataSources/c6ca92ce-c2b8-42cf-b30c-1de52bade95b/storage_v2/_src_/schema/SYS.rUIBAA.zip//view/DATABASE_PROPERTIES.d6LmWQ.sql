CREATE VIEW DATABASE_PROPERTIES AS
  select name, value$, comment$
  from x$props
/

