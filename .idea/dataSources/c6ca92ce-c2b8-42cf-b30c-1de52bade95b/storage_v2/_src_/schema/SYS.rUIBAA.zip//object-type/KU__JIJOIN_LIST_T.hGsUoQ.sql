CREATE type ku$_jijoin_list_t as table of ku$_jijoin_t
/

