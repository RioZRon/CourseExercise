CREATE type ku$_extloc_list_t
 as table of ku$_extloc_t
/

