CREATE type dm_transforms
                                       as table of dm_transform
/

