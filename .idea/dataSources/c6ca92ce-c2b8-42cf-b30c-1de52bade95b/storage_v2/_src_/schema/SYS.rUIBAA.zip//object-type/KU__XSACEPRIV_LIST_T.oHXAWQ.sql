CREATE type ku$_xsacepriv_list_t as table of ku$_xsacepriv_t;
/

