CREATE VIEW USER_MINING_MODEL_XFORMS AS
  select o.name, x.attr, x.subn, x.attrspec, x.expr,
       decode(bitand(x.properties,16),16,'YES','NO')
from sys.obj$ o, sys.modelxfm$ x
where o.obj#=x.mod#
  and o.owner#=userenv('SCHEMAID')
  and bitand(x.properties,256) != 0
/

