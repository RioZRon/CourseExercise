CREATE type dm_nested_binary_floats
                                      
  as table of dm_nested_binary_float
/

