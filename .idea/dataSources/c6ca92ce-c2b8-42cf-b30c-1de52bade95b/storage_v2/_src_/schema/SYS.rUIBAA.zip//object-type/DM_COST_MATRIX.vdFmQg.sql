CREATE type dm_cost_matrix
                                       as table of dm_cost_element
/

