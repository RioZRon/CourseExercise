CREATE TYPE     kupc$_mdReplOffsetsList AS TABLE OF SYS.kupc$_mdReplOffsets
/

