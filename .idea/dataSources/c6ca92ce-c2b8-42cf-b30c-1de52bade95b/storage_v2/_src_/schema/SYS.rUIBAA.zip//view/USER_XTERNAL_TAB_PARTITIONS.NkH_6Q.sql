CREATE VIEW USER_XTERNAL_TAB_PARTITIONS AS
  select o.name, o.subname, 'SYS', xt.default_dir,
       decode(xt.par_type, 1, 'BLOB', 2, 'CLOB',       'UNKNOWN'),
       case when xt.par_type = 2 then xt.param_clob else NULL end
from sys.external_tab$ xt, sys.obj$ o, sys.tabpart$ tp, sys.tab$ t
where o.obj# = xt.obj# and
      o.obj# = tp.obj# and
      tp.bo# = t.obj# and
      o.owner# = userenv('SCHEMAID') and
      o.namespace = 1 and o.remoteowner IS NULL and o.linkname IS NULL
union all -- COMPOSITE PARTITIONS
select o.name, o.subname, 'SYS', xt.default_dir,
       decode(xt.par_type, 1, 'BLOB', 2, 'CLOB',       'UNKNOWN'),
       case when xt.par_type = 2 then xt.param_clob else NULL end
from   sys.external_tab$ xt, sys.obj$ o, sys.tabcompart$ tcp, sys.tab$ t
where  o.obj# = xt.obj# and
       o.obj# = tcp.obj# and
       tcp.bo# = t.obj# and
       o.owner# = userenv('SCHEMAID') and
       o.namespace = 1 and o.remoteowner IS NULL and o.linkname IS NULL
/

