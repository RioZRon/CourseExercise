CREATE type create_table_cost_columns is varray(50000) of create_table_cost_colinfo
/

