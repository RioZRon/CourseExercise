CREATE type ku$_lobfrag_list_t as table of ku$_lob_t;
/

