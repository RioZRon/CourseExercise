CREATE type ku$_xsace_list_t as table of ku$_xsace_t;
/

