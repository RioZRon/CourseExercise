CREATE VIEW ALL_HIER_CLASS AS
  select owner,
       hier_name,
       classification,
       value,
       language,
       order_num,
       ORIGIN_CON_ID
from INT$DBA_HIER_CLASS
where OWNER = SYS_CONTEXT('USERENV', 'CURRENT_USER')
       or OWNER='PUBLIC'
       or OBJ_ID(OWNER, HIER_NAME, OBJECT_TYPE, OBJECT_ID) in
            ( select obj#  -- directly granted privileges
              from sys.objauth$
              where grantee# in ( select kzsrorol from x$kzsro )
            )
       or ora_check_sys_privilege(owner_id, object_type) = 1
/

