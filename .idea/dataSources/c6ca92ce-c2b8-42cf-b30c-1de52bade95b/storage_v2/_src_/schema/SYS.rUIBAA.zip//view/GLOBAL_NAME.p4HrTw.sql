CREATE VIEW GLOBAL_NAME AS
  select value$ from sys.props$ where name = 'GLOBAL_DB_NAME'
/

