CREATE type ku$_audit_act_list_t
  as table of ku$_audit_act_t
/

