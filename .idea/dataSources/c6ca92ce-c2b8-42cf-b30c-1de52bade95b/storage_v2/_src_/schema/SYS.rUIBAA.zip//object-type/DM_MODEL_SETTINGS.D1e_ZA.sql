CREATE type dm_model_settings
                                      
  as table of dm_model_setting
/

