CREATE type ku$_analytic_view_keys_list_t
  as table of ku$_analytic_view_keys_t
/

