CREATE type ku$_domidx_2ndtab_list_t
  as table of ku$_domidx_2ndtab_t
/

