CREATE TYPE     RewriteArrayType AS VARRAY(256) OF RewriteMessage
/

