CREATE type ku$_xsinstacl_list_t as table of ku$_xsinst_acl_t;
/

