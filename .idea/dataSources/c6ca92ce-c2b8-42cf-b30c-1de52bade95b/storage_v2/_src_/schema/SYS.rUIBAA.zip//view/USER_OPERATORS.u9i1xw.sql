CREATE VIEW USER_OPERATORS AS
  select c.name, b.name, a.numbind from
  sys.operator$ a, sys.obj$ b, sys.user$ c where
  a.obj# = b.obj# and b.owner# = c.user# and
  b.owner# = userenv ('SCHEMAID')
/

