CREATE type ku$_hcs_clsfctn_list_t as table of ku$_hcs_clsfctn_t
/

