CREATE type dm_nested_binary_doubles
                                      
  as table of dm_nested_binary_double
/

