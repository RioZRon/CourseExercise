CREATE VIEW GV_$VERSION AS
  select "INST_ID","BANNER","CON_ID" from gv$version
/

