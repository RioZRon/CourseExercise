CREATE TYPE     dbms_aw$_columnlist_t AS TABLE OF VARCHAR2(300)
/

