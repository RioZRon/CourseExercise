CREATE type ku$_file_list_t
  as table of ku$_file_t
/

