CREATE TYPE     ku$_chunk_list_t IS TABLE OF sys.ku$_chunk_t
/

