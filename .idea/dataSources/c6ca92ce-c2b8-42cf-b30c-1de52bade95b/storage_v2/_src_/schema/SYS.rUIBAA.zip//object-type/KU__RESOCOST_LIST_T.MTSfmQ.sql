CREATE type ku$_resocost_list_t as TABLE of ku$_resocost_item_t
/

