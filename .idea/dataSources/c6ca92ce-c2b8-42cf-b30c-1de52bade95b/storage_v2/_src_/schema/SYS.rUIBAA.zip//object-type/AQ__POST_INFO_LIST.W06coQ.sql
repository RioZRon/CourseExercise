CREATE TYPE     aq$_post_info_list
AS VARRAY(1024) OF sys.aq$_post_info
/

