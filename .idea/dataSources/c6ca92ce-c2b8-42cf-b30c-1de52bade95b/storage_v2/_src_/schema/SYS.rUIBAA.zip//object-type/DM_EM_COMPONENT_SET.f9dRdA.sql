CREATE type dm_em_component_set
                                       as table of dm_em_component
/

