CREATE VIEW ALL_ANALYTIC_VIEW_MEAS_CLASS AS
  select owner,
       analytic_view_name,
       measure_name,
       classification,
       value,
       language,
       order_num,
       origin_con_id
from INT$DBA_AVIEW_MEAS_CLASS
where OWNER = SYS_CONTEXT('USERENV', 'CURRENT_USER')
       or OWNER='PUBLIC'
       or OBJ_ID(OWNER, ANALYTIC_VIEW_NAME, OBJECT_TYPE, OBJECT_ID) in
            ( select obj#  -- directly granted privileges
              from sys.objauth$
              where grantee# in ( select kzsrorol from x$kzsro )
            )
       or ora_check_sys_privilege(owner_id, object_type) = 1
/

