CREATE type dm_model_global_details
                                       as table of dm_model_global_detail
/

