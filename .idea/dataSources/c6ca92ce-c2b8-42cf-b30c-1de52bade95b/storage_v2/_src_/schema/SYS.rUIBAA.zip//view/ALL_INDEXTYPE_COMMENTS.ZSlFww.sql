CREATE VIEW ALL_INDEXTYPE_COMMENTS AS
  select  u.name, o.name, c.comment$
from    sys.obj$ o, sys.user$ u, sys.indtypes$ i, sys.com$ c
where   o.obj# = i.obj# and u.user# = o.owner# and c.obj# = i.obj# and
( o.owner# = userenv ('SCHEMAID')
    or
    o.obj# in
            (select oa.obj#
             from sys.objauth$ oa
             where grantee# in ( select kzsrorol
                                 from x$kzsro
                               )
            )
       or ora_check_sys_privilege (o.owner#, o.type#) = 1
 )
/

