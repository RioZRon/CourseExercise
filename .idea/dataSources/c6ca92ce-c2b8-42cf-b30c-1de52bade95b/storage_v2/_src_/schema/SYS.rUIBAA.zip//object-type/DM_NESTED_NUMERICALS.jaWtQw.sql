CREATE type dm_nested_numericals
                                      
  as table of dm_nested_numerical
/

