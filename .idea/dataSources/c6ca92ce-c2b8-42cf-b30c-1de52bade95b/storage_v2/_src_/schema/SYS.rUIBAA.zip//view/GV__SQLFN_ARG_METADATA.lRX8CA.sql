CREATE VIEW GV_$SQLFN_ARG_METADATA AS
  select "INST_ID","FUNC_ID","ARGNUM","DATATYPE","DESCR","CON_ID" from gv$sqlfn_arg_metadata
/

