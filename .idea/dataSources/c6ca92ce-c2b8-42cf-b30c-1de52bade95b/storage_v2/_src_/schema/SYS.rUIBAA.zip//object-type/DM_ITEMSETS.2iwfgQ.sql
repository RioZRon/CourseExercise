CREATE type dm_itemsets
                                       as table of dm_itemset
/

