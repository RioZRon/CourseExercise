CREATE type ku$_add_snap_list_t as TABLE of ku$_add_snap_t;
/

