CREATE type ku$_user_editioning_list_t
  as table of ku$_user_editioning_t
/

