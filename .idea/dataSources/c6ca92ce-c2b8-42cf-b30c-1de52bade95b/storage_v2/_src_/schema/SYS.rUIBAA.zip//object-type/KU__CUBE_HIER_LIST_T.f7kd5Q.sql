CREATE type ku$_cube_hier_list_t
 as table of ku$_cube_hier_t
/

