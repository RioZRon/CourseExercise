CREATE VIEW ALL_SUMMAP AS
  select XID, COMMIT_SCN from sys.snap_xcmt$
/

