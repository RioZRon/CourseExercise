CREATE TYPE kupc$_table_datas AS VARRAY(1000) OF kupc$_table_data
/

