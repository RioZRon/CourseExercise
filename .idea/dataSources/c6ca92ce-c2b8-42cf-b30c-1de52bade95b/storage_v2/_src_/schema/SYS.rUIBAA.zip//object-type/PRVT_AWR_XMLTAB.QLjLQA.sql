CREATE TYPE prvt_awr_xmltab
AS TABLE OF XMLTYPE;
/

