CREATE VIEW V_$XS_SESSION_ROLES AS
  select "ROLE_WSPACE","ROLE_NAME","FLAGS","CON_ID" from v$xs_session_role
/

