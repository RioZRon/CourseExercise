CREATE VIEW LOADER_DIR_OBJS AS
  SELECT d.directory_name, d.directory_path, 'TRUE', 'TRUE', 'TRUE'
    FROM sys.obj$ o, sys.int$dba_directories d
   WHERE o.obj#=OBJ_ID(d.OWNER, d.DIRECTORY_NAME, d.OBJECT_TYPE#, d.OBJECT_ID)
     AND o.type# = 23
     AND ora_check_SYS_privilege (o.owner#, o.type#) = 1
  UNION ALL
  SELECT d.directory_name, d.directory_path,
         decode(sum(decode(oa.privilege#,17,1,0)),0, 'FALSE','TRUE'),
         decode(sum(decode(oa.privilege#,18,1,0)),0, 'FALSE','TRUE'),
         decode(sum(decode(oa.privilege#,12,1,0)),0, 'FALSE','TRUE')
    FROM sys.obj$ o, sys.int$dba_directories d, sys.objauth$ oa
   WHERE oa.obj#=OBJ_ID(d.OWNER, d.DIRECTORY_NAME, d.OBJECT_TYPE#, d.OBJECT_ID)
     AND o.type# = 23
     AND oa.obj#=o.obj#
     AND oa.privilege# IN (12,17,18)
     AND grantee# IN (SELECT kzsrorol FROM x$kzsro)
     AND ora_check_SYS_privilege (o.owner#, o.type#) != 1
    GROUP BY d.directory_name, d.directory_path
/

