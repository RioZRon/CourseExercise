CREATE VIEW NLS_DATABASE_PARAMETERS AS
  select name,
       substr(value$, 1, 64)
from x$props
where name like 'NLS%'
/

