CREATE type DM_MODEL_TEXT_DFS
                                      
  as table of DM_MODEL_TEXT_DF
/

