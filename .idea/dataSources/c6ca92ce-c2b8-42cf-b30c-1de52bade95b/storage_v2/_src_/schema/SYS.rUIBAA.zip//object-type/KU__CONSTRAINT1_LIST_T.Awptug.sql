CREATE type ku$_constraint1_list_t as table of ku$_constraint1_t;
/

