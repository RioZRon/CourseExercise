CREATE VIEW ALL_SEQUENCES AS
  select u.name, o.name,
      s.minvalue, s.maxvalue, s.increment$,
      decode (s.cycle#, 0, 'N', 1, 'Y'),
      decode (s.order$, 0, 'N', 1, 'Y'),
      s.cache, s.highwater,
      decode(bitand(s.flags, 16), 16, 'Y', 'N'),
      decode(bitand(s.flags, 2048), 2048, 'Y', 'N'),
      decode(bitand(s.flags, 64), 64, 'Y', 'N'),
      decode(bitand(s.flags, 512), 512, 'Y', 'N')
from sys.seq$ s, sys.obj$ o, sys.user$ u
where u.user# = o.owner#
  and o.obj# = s.obj#
  and (o.owner# = userenv('SCHEMAID')
       or o.obj# in
            (select oa.obj#
             from sys.objauth$ oa
             where grantee# in ( select kzsrorol
                                 from x$kzsro
                               )
            )
        or
        ora_check_sys_privilege ( o.owner#, o.type#) = 1
      )
  and (bitand(s.flags, 1024) = 0 or s.flags is null)
/

