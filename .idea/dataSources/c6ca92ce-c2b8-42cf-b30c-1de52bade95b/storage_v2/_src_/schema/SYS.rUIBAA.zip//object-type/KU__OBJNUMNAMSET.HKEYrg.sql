CREATE TYPE ku$_ObjNumNamSet  IS TABLE OF  ku$_ObjNumNam;
/

