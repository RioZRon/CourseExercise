CREATE TYPE sql_bind_set
                                                                      
AS TABLE OF sql_bind
/

