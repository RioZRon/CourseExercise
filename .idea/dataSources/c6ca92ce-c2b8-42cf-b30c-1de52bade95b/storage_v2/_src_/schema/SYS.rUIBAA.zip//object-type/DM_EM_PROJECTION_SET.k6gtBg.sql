CREATE type dm_em_projection_set
                                       as table of dm_em_projection
/

