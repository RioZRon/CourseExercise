CREATE type tablespace_list is varray (64000) of number
/

