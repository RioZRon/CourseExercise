CREATE type ku$_tlob_comppart_list_t as table of ku$_tlob_comppart_t
/

