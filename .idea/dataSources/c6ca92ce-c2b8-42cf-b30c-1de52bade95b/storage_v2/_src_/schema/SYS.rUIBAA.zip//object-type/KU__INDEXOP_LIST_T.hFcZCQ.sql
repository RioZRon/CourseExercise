CREATE type ku$_indexop_list_t as TABLE of ku$_indexop_t
/

