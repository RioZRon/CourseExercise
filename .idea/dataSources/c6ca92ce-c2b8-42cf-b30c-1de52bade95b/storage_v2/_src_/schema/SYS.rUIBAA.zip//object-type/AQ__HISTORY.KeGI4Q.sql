CREATE TYPE     aq$_history
                                                                      
AS VARRAY(1024) OF sys.aq$_dequeue_history
/

