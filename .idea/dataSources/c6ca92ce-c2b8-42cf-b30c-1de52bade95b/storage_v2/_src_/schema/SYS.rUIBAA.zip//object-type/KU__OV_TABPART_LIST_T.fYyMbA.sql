CREATE type ku$_ov_tabpart_list_t as table of ku$_ov_tabpart_t;
/

